# PixelStudio: feasibility prototype (milestone 1)

Goal of this milestone: prove that PhotoCraft's existing image code can run inside a real Android APK.
The app picks a PNG/JPEG, hands the bytes to Rust, which imports it, flattens it and returns pixels
to Kotlin for display, and exports a PNG through the same engine. Nothing else (no layers, brushes,
text, editing UI) is implemented on purpose.

## Status: NOTHING HAS BEEN COMPILED OR RUN YET

The authoring environment had no Rust toolchain, Android SDK/NDK, Gradle or network. Treat every
file as **uncompiled code**.

| Verified here | How |
|---|---|
| The upstream function signatures the bridge calls (`io::import`, `compose::flatten`, `Buffer::to_rgba8`, `io::export`, `ExportOptions`, `Document::bounds`, `Rect::width/height`) | read from the extracted upstream source |
| `rgba_2x2.png` is a valid PNG with known pixels | CRCs and zlib stream checked in Python |
| Dependency closure: 374 locked packages, only 2 git-sourced (`craft-docpath`, `craft-jpeg`, same repo and rev), no egui/winit/wgpu/winprint | `scripts/lock_closure.py` over upstream `Cargo.lock` (static; over-counts, see script) |
| Upstream licence/notice files copied byte-for-byte | `cp` from the archive |
| Upstream source unmodified | only read operations were run on it |

| NOT verified (do these locally, see checklist) |
|---|
| `cargo build`/`cargo test` for host and Android targets (including the `jni = 0.21.1` calls I wrote from memory, and the assumption that `Document` is `Send + Sync`) |
| Whether every crate in the closure cross-compiles for Android (`yeslogic-fontconfig-sys`, `cc`-built C code, `fontdb`/`resvg` system-fonts) |
| `cargo-ndk` flag spelling (`cargo ndk --help`), Gradle/AGP/Kotlin/Compose versions, Gradle wrapper (cannot be generated without Gradle) |
| Any emulator or physical-device behaviour, memory use, speed, JPEG import, colour accuracy |
| Offline/vendored builds; access to the git repository |

## Layout (the upstream checkout is a sibling and stays untouched)

```
pixelstudio/
  photocraft-main/        <- unzip photocraft-main.zip here, unchanged
  native/                 <- separate Cargo workspace
    photocraft-android-bridge/   cdylib -> libpixelstudio_bridge.so
  android/                <- Gradle project (Kotlin, Compose)
  docs/  scripts/  third_party/licenses/
```

## Setup: Linux

```bash
# 1. Upstream next to this repo
unzip /path/to/photocraft-main.zip -d pixelstudio/        # creates pixelstudio/photocraft-main
cd pixelstudio

# 2. Rust (upstream needs 1.95+) and Android targets
rustup update stable && rustc --version                    # must be >= 1.95
rustup target add aarch64-linux-android x86_64-linux-android
cargo install cargo-ndk --locked
sudo apt install build-essential                           # host linker for build scripts

# 3. Android SDK + NDK (Android Studio > SDK Manager > SDK Tools > NDK (Side by side))
export ANDROID_HOME=$HOME/Android/Sdk
export ANDROID_NDK_HOME=$ANDROID_HOME/ndk/<installed version>

# 4. Start from upstream's pinned versions (a copy; upstream's file is not touched)
cp photocraft-main/Cargo.lock native/Cargo.lock
```

## Setup: Windows (PowerShell)

```powershell
tar -xf photocraft-main.zip -C pixelstudio            # creates pixelstudio\photocraft-main
cd pixelstudio
# Rust via rustup-init.exe, plus Visual Studio Build Tools ("Desktop development with C++"):
# build scripts compile for the host and need link.exe even when targeting Android.
rustup update stable; rustc --version                 # must be >= 1.95
rustup target add aarch64-linux-android x86_64-linux-android
cargo install cargo-ndk --locked
setx ANDROID_HOME "$env:LOCALAPPDATA\Android\Sdk"
setx ANDROID_NDK_HOME "$env:LOCALAPPDATA\Android\Sdk\ndk\<installed version>"   # reopen the shell
git config --global core.longpaths true               # deep crate paths
Copy-Item photocraft-main\Cargo.lock native\Cargo.lock
```

## Build and verify (in this order)

```bash
# A. Host unit tests of the JNI-free core. First run downloads crates (network needed) and rewrites
#    native/Cargo.lock (do NOT pass --locked yet); commit the rewritten lock afterwards.
cd native && cargo test -p photocraft-android-bridge

# B. Cross-compile only, to see Android blockers early
cargo ndk --target arm64-v8a --platform 26 --output-dir ../android/app/build/rustJniLibs \
  build --release --package photocraft-android-bridge
cargo tree --target aarch64-linux-android -p photocraft-android-bridge | head -50   # authoritative closure

# C. Gradle wrapper (not shipped: needs Gradle). Either open android/ in Android Studio, or:
cd ../android && gradle wrapper --gradle-version 8.9

# D. Debug APK (runs the buildRust task first). Windows: gradlew.bat
./gradlew :app:assembleDebug
unzip -l app/build/outputs/apk/debug/app-debug.apk | grep pixelstudio_bridge   # .so present per ABI?

# E. Run on a device / emulator (x86_64 image for the emulator)
adb install -r app/build/outputs/apk/debug/app-debug.apk
./gradlew :app:connectedDebugAndroidTest          # JNI instrumented tests
```

Useful Gradle switch: `-Ppixelstudio.skipRust=true` skips the Rust task if you built the `.so` yourself.

## How the pieces connect

See `docs/BRIDGE_INTERFACE.md` (ownership, pixel format, stride, errors, JNI registration),
`docs/DEPENDENCIES.md` (git dependencies, vendoring) and `THIRD_PARTY_NOTICES.md` (licences).

## Known limitations of this milestone

- 12 megapixel cap and 8192 px per side; the compositor works in f32 (16 bytes per pixel), so peak
  native memory for a 12 MP image is roughly 190 MB (float buffer) plus 48 MB (RGBA8) plus the document.
- Pixels are copied Rust -> direct ByteBuffer -> Bitmap. `AndroidBitmap_lockPixels` would remove one copy.
- Whole-image flatten, no tiles, no zoom/pan yet.
- No colour management for display: the composite is in the document's colour space and is shown as-is.
- Export uses upstream's default `ExportOptions` (which embeds XMP metadata from the source). Decide
  that policy before shipping.
- JPEG import goes through the same path but has not been exercised.
- SAF writes (`openOutputStream(uri, "wt")`) are not atomic; the editable-project format will need its own safe-save.
- Handles live in process memory only.

## Branding

The app is named PixelStudio. It uses no PhotoCraft/ArtCraft name, wordmark, logo, icon or other asset.
The crate is called `photocraft-android-bridge` only because that was the requested name; rename it
if you want the name out of the shipped binary's metadata. Upstream's licence does not cover the
ArtCraft marks (see `THIRD_PARTY_NOTICES.md`).

## Checklist of commands still to run

- [ ] `rustc --version` is 1.95 or newer
- [ ] `cd native && cargo test -p photocraft-android-bridge` passes (A)
- [ ] cross-build for `arm64-v8a` and `x86_64` succeeds (B); paste errors if not
- [ ] `cargo tree --target aarch64-linux-android -p photocraft-android-bridge` reviewed for unexpected crates
- [ ] Gradle wrapper generated, `:app:assembleDebug` succeeds (C, D)
- [ ] `.so` present in the APK for both ABIs
- [ ] app opens a PNG on an emulator and on a device; exported PNG opens elsewhere
- [ ] `:app:connectedDebugAndroidTest` passes (E)
- [ ] try a ~12 MP JPEG and a PNG with transparency; note memory use and time
- [ ] `cargo vendor` + offline build (see DEPENDENCIES.md) if reproducibility matters
- [ ] licence audit of the full closure (`cargo about` or `cargo deny`)

## Automatic APK build on GitHub (Actions)

Workflow: `.github/workflows/build-apk.yml`. It installs Rust + cargo-ndk, builds the `.so` for both ABIs,
runs Gradle and uploads the APK as the artifact `PixelStudio-debug-apk`. **Not yet run**; send the log of
any failed step.

Repository contents (GitHub does not unzip uploads, so extract locally first):
1. Extract `pixelstudio-feasibility-prototype.zip` and upload the *contents* so `android/`, `native/`,
   `.github/` sit at the repository root (`.github` is a hidden folder: make sure it is included, or create
   `.github/workflows/build-apk.yml` with "Add file > Create new file" and paste the YAML).
2. Also add the original `photocraft-main.zip` to the repository root (about 22 MiB, under the browser's
   25 MiB per-file limit). The workflow unzips it. A committed `photocraft-main/` folder works too.
3. Open the Actions tab, run "Build APK" (or push), then download the artifact from the finished run.
