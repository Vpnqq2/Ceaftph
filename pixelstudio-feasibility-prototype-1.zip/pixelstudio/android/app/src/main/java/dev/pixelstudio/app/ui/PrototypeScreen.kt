package dev.pixelstudio.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.pixelstudio.app.MainViewModel

@Composable
fun PixelStudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(), content = content)
}

@Composable
fun PrototypeScreen(vm: MainViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()

    // A null result means the user cancelled the picker; nothing to do.
    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.openImage(uri)
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) vm.exportTo(uri)
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier.safeDrawingPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("PixelStudio", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Feasibility prototype: import, compositing and PNG export run in native Rust code.",
                style = MaterialTheme.typography.bodySmall,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { openLauncher.launch(arrayOf("image/png", "image/jpeg")) }, enabled = !state.busy) {
                    Text("Select image")
                }
                OutlinedButton(
                    onClick = { saveLauncher.launch("pixelstudio-export.png") },
                    enabled = state.canExport && !state.busy,
                ) { Text("Export PNG") }
            }
            if (state.busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            state.info?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
            state.message?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                val bitmap = state.bitmap
                if (bitmap == null) {
                    Text("No image yet. Tap Select image.", style = MaterialTheme.typography.bodyMedium)
                } else {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = "Image processed by the native engine",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
        }
    }
}
