plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Repo layout: <root>/android (this project), <root>/native (Cargo workspace), <root>/photocraft-main (upstream).
val repoRoot = rootProject.projectDir.parentFile
val rustOutDir = layout.buildDirectory.dir("rustJniLibs")
val skipRust = providers.gradleProperty("pixelstudio.skipRust").map { it.toBoolean() }.getOrElse(false)

android {
    namespace = "dev.pixelstudio.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "dev.pixelstudio.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-feasibility"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        ndk { abiFilters += listOf("arm64-v8a", "x86_64") }
    }

    buildFeatures { compose = true }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    sourceSets.getByName("main").jniLibs.srcDir(rustOutDir)

    packaging { jniLibs { useLegacyPackaging = false } }
}

// cargo-ndk drops <abi>/libpixelstudio_bridge.so under build/rustJniLibs, which is added to jniLibs above.
// Needs: rustup targets, `cargo install cargo-ndk`, and ANDROID_NDK_HOME pointing at an installed NDK.
val buildRust = tasks.register<Exec>("buildRust") {
    group = "rust"
    description = "Builds libpixelstudio_bridge.so for arm64-v8a and x86_64 with cargo-ndk."
    val nativeDir = File(repoRoot, "native")
    workingDir = nativeDir
    inputs.dir(File(nativeDir, "photocraft-android-bridge/src"))
    inputs.file(File(nativeDir, "photocraft-android-bridge/Cargo.toml"))
    inputs.file(File(nativeDir, "Cargo.toml"))
    outputs.dir(rustOutDir)
    commandLine(
        "cargo", "ndk",
        "--target", "arm64-v8a",
        "--target", "x86_64",
        "--platform", "26",
        "--output-dir", rustOutDir.get().asFile.absolutePath,
        "build", "--release", "--package", "photocraft-android-bridge",
    )
    onlyIf { !skipRust }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(buildRust) }

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")

    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
}
