// Plugin versions are my best knowledge of a known-compatible set (AGP 8.7 + Kotlin 2.0 + Compose
// compiler plugin) and have NOT been resolved or built in this environment. Update if Android
// Studio proposes an upgrade.
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
}
