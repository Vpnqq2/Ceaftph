package dev.pixelstudio.app.bridge

import java.nio.ByteBuffer

/** Thrown by the native layer for every failure (bad input, invalid handle, panic, ...). */
class NativeException(message: String) : RuntimeException(message)

/**
 * Raw JNI surface of libpixelstudio_bridge.so. Prefer [NativeImage]; it owns the handle lifecycle.
 *
 * Symbols are resolved by name (`Java_dev_pixelstudio_app_bridge_NativeBridge_<method>`), which is
 * why these are `@JvmStatic` and why this package and class must not be renamed or obfuscated
 * without also changing jni_glue.rs. If R8 minification is ever enabled, keep this class.
 */
object NativeBridge {
    /** Must equal ABI_VERSION in native/photocraft-android-bridge/src/bridge_core.rs. */
    const val EXPECTED_ABI_VERSION = 3

    init {
        System.loadLibrary("pixelstudio_bridge")
        val actual = nativeAbiVersion()
        check(actual == EXPECTED_ABI_VERSION) { "native ABI $actual, app expects $EXPECTED_ABI_VERSION" }
    }

    @JvmStatic external fun nativeAbiVersion(): Int
    @JvmStatic external fun nativeMaxPixels(): Long

    /** Decodes [bytes] (file contents; copied) and returns a non-zero handle, or throws [NativeException]. */
    @JvmStatic external fun nativeOpen(bytes: ByteArray, name: String): Long
    @JvmStatic external fun nativeWidth(handle: Long): Int
    @JvmStatic external fun nativeHeight(handle: Long): Int

    /**
     * Writes premultiplied RGBA8 (row stride = width * 4, top row first) into [dst], which must be a
     * direct ByteBuffer of at least width * height * 4 bytes. Position/limit are ignored.
     */
    @JvmStatic external fun nativeRenderPremultiplied(handle: Long, dst: ByteBuffer)

    /** Encodes the document as PNG; the returned array is owned by the caller. */
    @JvmStatic external fun nativeExportPng(handle: Long): ByteArray

    /** Encodes the document as JPEG, [quality] 1..=100; the returned array is owned by the caller. */
    @JvmStatic external fun nativeExportJpeg(handle: Long, quality: Int): ByteArray

    /** Exporter warnings for the most recent export, one per line; empty if none. */
    @JvmStatic external fun nativeLastExportWarnings(): String

    // ---- Full PhotoCraft engine session (ABI 3). Only works in builds made with `--features engine`;
    // otherwise everything except nativeEngineAvailable throws NativeException. One session per process,
    // operating on its active document.
    @JvmStatic external fun nativeEngineAvailable(): Boolean
    @JvmStatic external fun nativeEngineOpen(bytes: ByteArray, name: String)

    /** Runs an engine command by id with JSON params ("" = {}); returns its JSON result. */
    @JvmStatic external fun nativeEngineExecute(commandId: String, paramsJson: String): String

    /** JSON array of all commands: id, label, menu, shortcut, params description. */
    @JvmStatic external fun nativeEngineCommands(): String
    @JvmStatic external fun nativeEngineWidth(): Int
    @JvmStatic external fun nativeEngineHeight(): Int

    /** Same buffer contract as [nativeRenderPremultiplied], for the engine's active document. */
    @JvmStatic external fun nativeEngineRender(dst: ByteBuffer)
    @JvmStatic external fun nativeEngineExportPng(): ByteArray
    @JvmStatic external fun nativeEngineExportJpeg(quality: Int): ByteArray

    /** Returns false if the handle was unknown (already closed). */
    @JvmStatic external fun nativeClose(handle: Long): Boolean
}
