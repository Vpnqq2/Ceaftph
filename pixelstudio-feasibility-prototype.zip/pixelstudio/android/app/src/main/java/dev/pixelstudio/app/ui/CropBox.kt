package dev.pixelstudio.app.ui

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Which part of the crop box a finger is dragging. (hx, hy) say which edges move: -1 left/top, +1 right/bottom. */
enum class CropHandle(val hx: Int, val hy: Int) {
    TOP_LEFT(-1, -1), TOP(0, -1), TOP_RIGHT(1, -1), RIGHT(1, 0),
    BOTTOM_RIGHT(1, 1), BOTTOM(0, 1), BOTTOM_LEFT(-1, 1), LEFT(-1, 0), BODY(0, 0),
}

/** Whole-pixel crop rectangle, in the form the engine's `image.crop` takes. */
data class CropRect(val x: Int, val y: Int, val width: Int, val height: Int)

/**
 * Crop rectangle in IMAGE pixel coordinates (not screen). Pure Kotlin, JVM-tested.
 * All operations keep the box inside the image and at least [MIN_SIZE] pixels per side.
 */
data class CropBox(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top

    /** Translate by (dx, dy) image pixels, stopping at the image edges. */
    fun moved(dx: Float, dy: Float, iw: Float, ih: Float): CropBox {
        val nx = (left + dx).coerceIn(0f, max(0f, iw - width))
        val ny = (top + dy).coerceIn(0f, max(0f, ih - height))
        return CropBox(nx, ny, nx + width, ny + height)
    }

    /**
     * Drag [handle] by (dx, dy) image pixels. With a locked [aspect] (width / height) only corner handles
     * resize, keeping the opposite corner fixed; edge handles are ignored then.
     */
    fun resized(handle: CropHandle, dx: Float, dy: Float, iw: Float, ih: Float, aspect: Float? = null): CropBox {
        if (handle == CropHandle.BODY) return moved(dx, dy, iw, ih)
        if (aspect != null) {
            if (handle.hx == 0 || handle.hy == 0) return this
            return resizedCorner(handle, dx, dy, iw, ih, aspect)
        }
        var l = left
        var t = top
        var r = right
        var b = bottom
        if (handle.hx == -1) l = (left + dx).coerceIn(0f, right - MIN_SIZE)
        if (handle.hx == 1) r = (right + dx).coerceIn(left + MIN_SIZE, iw)
        if (handle.hy == -1) t = (top + dy).coerceIn(0f, bottom - MIN_SIZE)
        if (handle.hy == 1) b = (bottom + dy).coerceIn(top + MIN_SIZE, ih)
        return CropBox(l, t, r, b)
    }

    private fun resizedCorner(handle: CropHandle, dx: Float, dy: Float, iw: Float, ih: Float, aspect: Float): CropBox {
        val sx = handle.hx
        val sy = handle.hy
        val ax = if (sx > 0) left else right // anchor = the opposite corner
        val ay = if (sy > 0) top else bottom
        val wantW = width + sx * dx
        val wantH = height + sy * dy
        // follow whichever finger movement is larger, expressed as a width
        var w = if (abs(dx) >= abs(dy * aspect)) wantW else wantH * aspect
        val availW = if (sx > 0) iw - ax else ax
        val availH = if (sy > 0) ih - ay else ay
        val maxW = min(availW, availH * aspect)
        val minW = max(MIN_SIZE, MIN_SIZE * aspect)
        w = w.coerceIn(min(minW, maxW), maxW)
        val h = w / aspect
        return CropBox(
            left = if (sx > 0) ax else ax - w,
            top = if (sy > 0) ay else ay - h,
            right = if (sx > 0) ax + w else ax,
            bottom = if (sy > 0) ay + h else ay,
        )
    }

    /** Rounded to whole pixels, at least 1x1. */
    fun toRect(): CropRect {
        val x0 = left.roundToInt()
        val y0 = top.roundToInt()
        return CropRect(x0, y0, max(1, right.roundToInt() - x0), max(1, bottom.roundToInt() - y0))
    }

    companion object {
        const val MIN_SIZE = 16f

        fun full(iw: Float, ih: Float) = CropBox(0f, 0f, iw, ih)

        /** Largest box with [aspect] (width / height) that fits the image, centred. */
        fun fitted(aspect: Float, iw: Float, ih: Float): CropBox {
            val w: Float
            val h: Float
            if (iw / ih > aspect) { h = ih; w = ih * aspect } else { w = iw; h = iw / aspect }
            val l = (iw - w) / 2f
            val t = (ih - h) / 2f
            return CropBox(l, t, l + w, t + h)
        }

        /**
         * Hit test in SCREEN pixels against the box's screen rectangle. Corners win over edges, edges over the
         * body; [slop] is the touch radius. Edges are skipped when [allowEdges] is false (aspect locked).
         */
        fun hit(l: Float, t: Float, r: Float, b: Float, x: Float, y: Float, slop: Float, allowEdges: Boolean): CropHandle? {
            fun near(cx: Float, cy: Float) = abs(x - cx) <= slop && abs(y - cy) <= slop
            if (near(l, t)) return CropHandle.TOP_LEFT
            if (near(r, t)) return CropHandle.TOP_RIGHT
            if (near(r, b)) return CropHandle.BOTTOM_RIGHT
            if (near(l, b)) return CropHandle.BOTTOM_LEFT
            if (allowEdges) {
                if (abs(y - t) <= slop && x in l..r) return CropHandle.TOP
                if (abs(y - b) <= slop && x in l..r) return CropHandle.BOTTOM
                if (abs(x - l) <= slop && y in t..b) return CropHandle.LEFT
                if (abs(x - r) <= slop && y in t..b) return CropHandle.RIGHT
            }
            if (x in l..r && y in t..b) return CropHandle.BODY
            return null
        }
    }
}
