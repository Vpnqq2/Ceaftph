package dev.pixelstudio.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import kotlin.math.max

/**
 * Crop frame drawn over the zoomed image and dragged with one finger. Touches that start away from the frame
 * or its handles are left unconsumed, so pinch-zoom and pan keep working underneath.
 * The drag is reported in IMAGE pixels via [onDrag]; the handle is decided once, when the finger goes down.
 */
@Composable
fun CropOverlay(
    box: CropBox,
    transform: ViewTransform,
    imageWidth: Float,
    imageHeight: Float,
    aspectLocked: Boolean,
    onDrag: (CropHandle, Float, Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    val boxNow by rememberUpdatedState(box)
    val transformNow by rememberUpdatedState(transform)
    val lockedNow by rememberUpdatedState(aspectLocked)
    val dragNow by rememberUpdatedState(onDrag)

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(imageWidth, imageHeight) {
                val slop = 28.dp.toPx()
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val cw = size.width.toFloat()
                    val ch = size.height.toFloat()
                    val t = transformNow
                    val b = boxNow
                    val scale = t.actualScale(cw, ch, imageWidth, imageHeight)
                    if (scale <= 0f) return@awaitEachGesture
                    val (l, top) = t.imageToScreen(b.left, b.top, cw, ch, imageWidth, imageHeight)
                    val (r, bottom) = t.imageToScreen(b.right, b.bottom, cw, ch, imageWidth, imageHeight)
                    val handle = CropBox.hit(l, top, r, bottom, down.position.x, down.position.y, slop, !lockedNow)
                        ?: return@awaitEachGesture
                    down.consume()
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!change.pressed) break
                        val delta = change.positionChange()
                        if (delta != Offset.Zero) dragNow(handle, delta.x / scale, delta.y / scale)
                        change.consume()
                    }
                }
            },
    ) {
        val cw = size.width
        val ch = size.height
        val (l, t) = transform.imageToScreen(box.left, box.top, cw, ch, imageWidth, imageHeight)
        val (r, b) = transform.imageToScreen(box.right, box.bottom, cw, ch, imageWidth, imageHeight)
        val dim = Color.Black.copy(alpha = 0.55f)
        // dim everything outside the frame
        drawRect(dim, Offset(0f, 0f), Size(cw, max(0f, t)))
        drawRect(dim, Offset(0f, b), Size(cw, max(0f, ch - b)))
        drawRect(dim, Offset(0f, t), Size(max(0f, l), max(0f, b - t)))
        drawRect(dim, Offset(r, t), Size(max(0f, cw - r), max(0f, b - t)))
        // frame and rule-of-thirds guides
        val line = Color.White.copy(alpha = 0.35f)
        for (i in 1..2) {
            val gx = l + (r - l) * i / 3f
            val gy = t + (b - t) * i / 3f
            drawLine(line, Offset(gx, t), Offset(gx, b), strokeWidth = 1.dp.toPx())
            drawLine(line, Offset(l, gy), Offset(r, gy), strokeWidth = 1.dp.toPx())
        }
        drawRect(Color.White, Offset(l, t), Size(r - l, b - t), style = Stroke(width = 2.dp.toPx()))
        // handles
        val corner = 7.dp.toPx()
        for (p in listOf(Offset(l, t), Offset(r, t), Offset(r, b), Offset(l, b))) drawCircle(Color.White, corner, p)
        if (!aspectLocked) {
            val e = 5.dp.toPx()
            for (p in listOf(Offset((l + r) / 2f, t), Offset((l + r) / 2f, b), Offset(l, (t + b) / 2f), Offset(r, (t + b) / 2f))) {
                drawRect(Color.White, Offset(p.x - e, p.y - e), Size(e * 2f, e * 2f))
            }
        }
    }
}
