package dev.pixelstudio.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.pixelstudio.app.ExportFormat
import dev.pixelstudio.app.MainViewModel
import kotlin.math.roundToInt

@Composable
fun PixelStudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(), content = content)
}

@Composable
fun PrototypeScreen(vm: MainViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    var scale by remember { mutableFloatStateOf(0f) }
    var tab by remember { mutableIntStateOf(0) }

    // A null result means the user cancelled the picker; nothing to do.
    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.openImage(uri)
    }
    val savePng = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) vm.exportTo(uri, ExportFormat.PNG)
    }
    val saveJpeg = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/jpeg")) { uri ->
        if (uri != null) vm.exportTo(uri, ExportFormat.JPEG)
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier.safeDrawingPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("PixelStudio", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Feasibility prototype: import, compositing and export run in native Rust code.",
                style = MaterialTheme.typography.bodySmall,
            )
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Viewer") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Engine") })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { openLauncher.launch(arrayOf("image/png", "image/jpeg")) }, enabled = !state.busy) {
                    Text("Select image")
                }
                OutlinedButton(onClick = { savePng.launch("pixelstudio-export.png") }, enabled = state.canExport && !state.busy) {
                    Text("Export PNG")
                }
            }
            if (tab == 0) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { saveJpeg.launch("pixelstudio-export.jpg") }, enabled = state.canExport && !state.busy) {
                    Text("Export JPEG")
                }
                Text("Quality ${state.jpegQuality}", style = MaterialTheme.typography.bodyMedium)
            }
            Slider(
                value = state.jpegQuality.toFloat(),
                onValueChange = { vm.setJpegQuality(it.roundToInt()) },
                valueRange = 50f..100f,
                enabled = state.canExport && !state.busy,
            )
            }
            if (state.busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            state.info?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
            state.message?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
            val bitmap = state.bitmap
            if (tab == 0) {
                if (bitmap != null) {
                    Text(
                        "Zoom ${(scale * 100).roundToInt()}%  (pinch, drag, double-tap for fit / 1:1)",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    if (bitmap == null) {
                        Text("No image yet. Tap Select image.", style = MaterialTheme.typography.bodyMedium)
                    } else {
                        ZoomableImage(bitmap = bitmap, modifier = Modifier.fillMaxSize(), onScaleChanged = { scale = it })
                    }
                }
            } else {
                EngineTab(state = state, vm = vm, modifier = Modifier.weight(1f).fillMaxWidth())
            }
        }
    }
}

/** Developer console for the full PhotoCraft engine (only present in builds made with `--features engine`). */
@Composable
private fun EngineTab(state: dev.pixelstudio.app.UiState, vm: MainViewModel, modifier: Modifier = Modifier) {
    var query by remember { mutableStateOf("") }
    var commandId by remember { mutableStateOf("image.crop") }
    var params by remember { mutableStateOf("{\"x\":0,\"y\":0,\"width\":100,\"height\":100}") }
    val ready = state.canExport && !state.busy
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            if (state.engineAvailable) "Full native engine: available in this build." else "This APK was built without the full engine (base build).",
            style = MaterialTheme.typography.bodyMedium,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.engineLoad() }, enabled = ready && state.engineAvailable) { Text("Load into engine") }
            OutlinedButton(onClick = { vm.engineRun("edit.undo", "{}") }, enabled = ready && state.engineActive) { Text("Undo") }
            OutlinedButton(onClick = { vm.engineRun("edit.redo", "{}") }, enabled = ready && state.engineActive) { Text("Redo") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Search commands") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedButton(onClick = { vm.engineFind(query) }, enabled = !state.busy && state.engineAvailable) { Text("Find") }
        }
        OutlinedTextField(value = commandId, onValueChange = { commandId = it }, label = { Text("Command id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = params, onValueChange = { params = it }, label = { Text("Params (JSON)") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { vm.engineRun(commandId, params) }, enabled = ready && state.engineActive) { Text("Run command") }
        Text("After a command the Viewer tab shows the engine's result; export then uses the engine document.", style = MaterialTheme.typography.bodySmall)
        SelectionContainer(modifier = Modifier.weight(1f).fillMaxWidth()) {
            Text(
                state.engineOutput.ifEmpty { "Output appears here." },
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp),
                modifier = Modifier.verticalScroll(rememberScrollState()),
            )
        }
    }
}
