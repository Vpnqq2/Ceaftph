package dev.pixelstudio.app

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dev.pixelstudio.app.bridge.EngineSession
import dev.pixelstudio.app.bridge.NativeBridge
import dev.pixelstudio.app.bridge.NativeException
import dev.pixelstudio.app.bridge.NativeImage
import dev.pixelstudio.app.ui.CropBox
import dev.pixelstudio.app.ui.CropHandle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.nio.ByteBuffer

enum class ExportFormat(val label: String) { PNG("PNG"), JPEG("JPEG") }

/** Tools shown in the bottom bar. Only tools that actually work are listed. */
enum class Tool { VIEW, CROP, CONSOLE }

enum class CropAspect(val label: String, val ratio: Float?) {
    FREE("Free", null),
    SQUARE("1:1", 1f),
    R4_3("4:3", 4f / 3f),
    R3_4("3:4", 3f / 4f),
    R16_9("16:9", 16f / 9f),
    R9_16("9:16", 9f / 16f),
}

data class UiState(
    val busy: Boolean = false,
    val jpegQuality: Int = 90,
    val bitmap: Bitmap? = null,
    val name: String? = null,
    val message: String? = null,
    val canExport: Boolean = false,
    /** True when this APK was built with the full engine feature. */
    val engineAvailable: Boolean = false,
    /** True when the shown image and the export come from the engine session. */
    val engineActive: Boolean = false,
    val engineOutput: String = "",
    val tool: Tool = Tool.VIEW,
    val crop: CropBox? = null,
    val cropAspect: CropAspect = CropAspect.FREE,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val resolver = app.contentResolver
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    /** Only used by the base build (no engine): the handle-based document. */
    private var image: NativeImage? = null

    private class Loaded(val image: NativeImage?, val bitmap: Bitmap, val name: String, val engine: Boolean)
    private class EngineResult(val text: String, val bitmap: Bitmap?)

    // ---------------------------------------------------------------- open / export

    /** [uri] comes from the system document picker (no storage permission needed). */
    fun openImage(uri: Uri) {
        if (_state.value.busy) return
        _state.update { it.copy(busy = true, message = "Opening...") }
        viewModelScope.launch {
            runCatching { withContext(Dispatchers.Default) { load(uri) } }
                .onSuccess { loaded ->
                    image?.close()
                    image = loaded.image
                    _state.value = UiState(
                        bitmap = loaded.bitmap,
                        name = loaded.name,
                        canExport = true,
                        engineAvailable = loaded.engine,
                        engineActive = loaded.engine,
                        jpegQuality = _state.value.jpegQuality,
                        message = if (loaded.engine) "Opened in the editing engine." else "Opened (base build: viewing and export only).",
                    )
                }
                .onFailure { e -> _state.update { it.copy(busy = false, message = describe(e)) } }
        }
    }

    fun setJpegQuality(quality: Int) {
        _state.update { it.copy(jpegQuality = quality.coerceIn(1, 100)) }
    }

    fun exportTo(uri: Uri, format: ExportFormat) {
        val handleImage = image
        if (_state.value.busy || (!_state.value.engineActive && handleImage == null)) return
        _state.update { it.copy(busy = true, message = "Exporting...") }
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val fromEngine = _state.value.engineActive
                    val q = _state.value.jpegQuality
                    val bytes = when (format) {
                        ExportFormat.PNG -> if (fromEngine) EngineSession.exportPng() else handleImage!!.exportPng()
                        ExportFormat.JPEG -> if (fromEngine) EngineSession.exportJpeg(q) else handleImage!!.exportJpeg(q)
                    }
                    val notes = if (fromEngine) "" else handleImage!!.lastExportWarnings()
                    val out = resolver.openOutputStream(uri, "wt") ?: throw IOException("could not open the destination file")
                    out.use { it.write(bytes) }
                    bytes.size to notes
                }
            }
            _state.update {
                it.copy(
                    busy = false,
                    message = result.fold(
                        { (n, notes) -> "Exported $n bytes as ${format.label}." + if (notes.isNotBlank()) "\nEngine notes: $notes" else "" },
                        { e -> "Export failed: ${describe(e)}" },
                    ),
                )
            }
        }
    }

    // ---------------------------------------------------------------- tools

    fun setTool(tool: Tool) {
        _state.update { st ->
            val bmp = st.bitmap
            when {
                tool == Tool.CROP && (bmp == null || !st.engineActive) ->
                    st.copy(message = "Crop needs an open image and the engine build of the app.")
                tool == Tool.CROP -> st.copy(tool = tool, crop = initialCrop(bmp!!, st.cropAspect), message = null)
                else -> st.copy(tool = tool, crop = null)
            }
        }
    }

    private fun initialCrop(bmp: Bitmap, aspect: CropAspect): CropBox {
        val w = bmp.width.toFloat()
        val h = bmp.height.toFloat()
        return aspect.ratio?.let { CropBox.fitted(it, w, h) } ?: CropBox.full(w, h)
    }

    /** (dx, dy) are image pixels. */
    fun cropDrag(handle: CropHandle, dx: Float, dy: Float) {
        _state.update { st ->
            val box = st.crop ?: return@update st
            val bmp = st.bitmap ?: return@update st
            st.copy(crop = box.resized(handle, dx, dy, bmp.width.toFloat(), bmp.height.toFloat(), st.cropAspect.ratio))
        }
    }

    fun setCropAspect(aspect: CropAspect) {
        _state.update { st ->
            val bmp = st.bitmap ?: return@update st
            val ratio = aspect.ratio
            st.copy(
                cropAspect = aspect,
                crop = if (ratio != null) CropBox.fitted(ratio, bmp.width.toFloat(), bmp.height.toFloat()) else st.crop,
            )
        }
    }

    /** Crops the engine document to the frame with the engine's `image.crop` (one undo step). */
    fun applyCrop() {
        val rect = _state.value.crop?.toRect() ?: return
        editTask("Cropping...", after = { it.copy(tool = Tool.VIEW, crop = null) }) {
            EngineSession.execute("image.crop", """{"x":${rect.x},"y":${rect.y},"width":${rect.width},"height":${rect.height}}""")
            val bmp = EngineSession.renderBitmap()
            EngineResult("Cropped to ${bmp.width}x${bmp.height}.", bmp)
        }
    }

    fun undo() = history("edit.undo", "Undone.")
    fun redo() = history("edit.redo", "Redone.")

    private fun history(commandId: String, done: String) {
        if (!_state.value.engineActive) {
            _state.update { it.copy(message = "Undo and redo need the engine build of the app.") }
            return
        }
        editTask("Working...", after = { it.copy(tool = if (it.tool == Tool.CONSOLE) Tool.CONSOLE else Tool.VIEW, crop = null) }) {
            EngineSession.execute(commandId, "{}")
            EngineResult(done, EngineSession.renderBitmap())
        }
    }

    /** Runs engine work off the main thread; the result becomes the new preview and status message. */
    private fun editTask(busyText: String, after: (UiState) -> UiState = { it }, block: () -> EngineResult) {
        if (_state.value.busy) return
        _state.update { it.copy(busy = true, message = busyText) }
        viewModelScope.launch {
            runCatching { withContext(Dispatchers.Default) { block() } }
                .onSuccess { r ->
                    _state.update { after(it.copy(busy = false, message = r.text, bitmap = r.bitmap ?: it.bitmap)) }
                }
                .onFailure { e -> _state.update { it.copy(busy = false, message = describe(e)) } }
        }
    }

    // ---------------------------------------------------------------- developer console

    /** Lists engine commands whose id or label contains [query] (all, counted, when empty). */
    fun consoleFind(query: String) = consoleTask("Reading the command list...") {
        val all = JSONArray(EngineSession.commandsJson())
        val q = query.trim().lowercase()
        val lines = ArrayList<String>()
        var matches = 0
        for (i in 0 until all.length()) {
            val c = all.getJSONObject(i)
            val id = c.optString("id")
            val label = c.optString("label")
            if (q.isEmpty() || id.lowercase().contains(q) || label.lowercase().contains(q)) {
                matches++
                if (lines.size < 15) lines += "$id  ($label)\n    params: ${c.optString("params").take(220)}"
            }
        }
        EngineResult("${all.length()} commands in total, $matches match.\n" + lines.joinToString("\n"), null)
    }

    /** Runs one engine command by id with JSON params, then refreshes the preview. */
    fun consoleRun(commandId: String, paramsJson: String) = consoleTask("Running $commandId...") {
        val result = EngineSession.execute(commandId.trim(), paramsJson)
        val bitmap = runCatching { EngineSession.renderBitmap() }.getOrNull()
        EngineResult("$commandId -> ${result.take(3000)}", bitmap)
    }

    private fun consoleTask(busyText: String, block: () -> EngineResult) {
        if (_state.value.busy) return
        _state.update { it.copy(busy = true, engineOutput = busyText) }
        viewModelScope.launch {
            runCatching { withContext(Dispatchers.Default) { block() } }
                .onSuccess { r -> _state.update { it.copy(busy = false, engineOutput = r.text, bitmap = r.bitmap ?: it.bitmap, crop = null) } }
                .onFailure { e -> _state.update { it.copy(busy = false, engineOutput = "Error: ${describe(e)}") } }
        }
    }

    // ---------------------------------------------------------------- loading

    private fun load(uri: Uri): Loaded {
        val name = displayName(uri) ?: "image"
        val bytes = readCapped(uri)

        // Cheap header-only check with Android's decoder before any big allocation.
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw IllegalArgumentException("This does not look like a PNG or JPEG image.")
        }
        if (bounds.outWidth > MAX_SIDE || bounds.outHeight > MAX_SIDE) {
            throw IllegalArgumentException("Image is ${bounds.outWidth}x${bounds.outHeight}; the prototype shows at most $MAX_SIDE px per side.")
        }
        if (bounds.outWidth.toLong() * bounds.outHeight > NativeBridge.nativeMaxPixels()) {
            throw IllegalArgumentException("Image is too large for the prototype (limit ${NativeBridge.nativeMaxPixels()} pixels).")
        }

        if (runCatching { EngineSession.isAvailable() }.getOrDefault(false)) {
            // Engine build: the engine session is the single source of truth for the document.
            runCatching { EngineSession.execute("file.closeAll", "{}") } // drop the previous document; errors (none open) are fine
            EngineSession.open(bytes, name)
            return Loaded(null, EngineSession.renderBitmap(), name, engine = true)
        }

        val img = NativeImage.open(bytes, name)
        try {
            val buffer = ByteBuffer.allocateDirect(img.pixelBufferSize)
            img.renderPremultiplied(buffer)
            buffer.rewind()
            val bitmap = Bitmap.createBitmap(img.width, img.height, Bitmap.Config.ARGB_8888)
            bitmap.copyPixelsFromBuffer(buffer)
            return Loaded(img, bitmap, name, engine = false)
        } catch (t: Throwable) {
            img.close()
            throw t
        }
    }

    private fun readCapped(uri: Uri): ByteArray {
        val input = resolver.openInputStream(uri) ?: throw IOException("could not open the selected file")
        input.use { stream ->
            val out = ByteArrayOutputStream()
            val chunk = ByteArray(64 * 1024)
            while (true) {
                val n = stream.read(chunk)
                if (n < 0) break
                out.write(chunk, 0, n)
                if (out.size() > MAX_FILE_BYTES) throw IllegalArgumentException("File is larger than ${MAX_FILE_BYTES / (1024 * 1024)} MiB.")
            }
            return out.toByteArray()
        }
    }

    private fun displayName(uri: Uri): String? =
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }

    private fun describe(e: Throwable): String = when (e) {
        is OutOfMemoryError -> "Not enough memory to process this image."
        is NativeException -> e.message ?: "Native engine error."
        is UnsatisfiedLinkError -> "The native library could not be loaded: ${e.message}"
        is ExceptionInInitializerError -> "The native library failed to initialise: ${e.cause?.message ?: e.message}"
        is IOException, is IllegalArgumentException -> e.message ?: e.javaClass.simpleName
        else -> "${e.javaClass.simpleName}: ${e.message}"
    }

    override fun onCleared() {
        image?.close()
        image = null
    }

    private companion object {
        const val MAX_FILE_BYTES = 64 * 1024 * 1024
        const val MAX_SIDE = 8192
    }
}
