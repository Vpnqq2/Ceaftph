package dev.pixelstudio.app

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dev.pixelstudio.app.bridge.EngineSession
import dev.pixelstudio.app.bridge.NativeBridge
import dev.pixelstudio.app.bridge.NativeException
import dev.pixelstudio.app.bridge.NativeImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.nio.ByteBuffer

enum class ExportFormat(val label: String) { PNG("PNG"), JPEG("JPEG") }

data class UiState(
    val busy: Boolean = false,
    val jpegQuality: Int = 90,
    val bitmap: Bitmap? = null,
    val info: String? = null,
    val message: String? = null,
    val canExport: Boolean = false,
    /** True when this APK was built with the PhotoCraft engine feature. */
    val engineAvailable: Boolean = false,
    /** True once the shown preview and the export come from the engine session. */
    val engineActive: Boolean = false,
    val engineOutput: String = "",
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val resolver = app.contentResolver
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()
    private var image: NativeImage? = null
    private var sourceBytes: ByteArray? = null
    private var sourceName: String = "image"

    private class Loaded(val image: NativeImage, val bitmap: Bitmap, val info: String, val bytes: ByteArray, val name: String, val engineAvailable: Boolean)

    /** [uri] comes from the system document picker (no storage permission needed). */
    fun openImage(uri: Uri) {
        if (_state.value.busy) return
        _state.update { it.copy(busy = true, message = null) }
        viewModelScope.launch {
            runCatching { withContext(Dispatchers.Default) { load(uri) } }
                .onSuccess { loaded ->
                    image?.close()
                    image = loaded.image
                    sourceBytes = loaded.bytes
                    sourceName = loaded.name
                    _state.value = UiState(
                        engineAvailable = loaded.engineAvailable,
                        bitmap = loaded.bitmap,
                        info = loaded.info,
                        message = "Imported and composited by the native engine.",
                        canExport = true,
                    )
                }
                .onFailure { e -> _state.update { it.copy(busy = false, message = describe(e)) } }
        }
    }

    fun setJpegQuality(quality: Int) {
        _state.update { it.copy(jpegQuality = quality.coerceIn(1, 100)) }
    }

    fun exportTo(uri: Uri, format: ExportFormat) {
        val img = image ?: return
        if (_state.value.busy) return
        _state.update { it.copy(busy = true, message = null) }
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val fromEngine = _state.value.engineActive
                    val q = _state.value.jpegQuality
                    val bytes = when (format) {
                        ExportFormat.PNG -> if (fromEngine) EngineSession.exportPng() else img.exportPng()
                        ExportFormat.JPEG -> if (fromEngine) EngineSession.exportJpeg(q) else img.exportJpeg(q)
                    }
                    val notes = img.lastExportWarnings()
                    val out = resolver.openOutputStream(uri, "wt") ?: throw IOException("could not open the destination file")
                    out.use { it.write(bytes) }
                    bytes.size to notes
                }
            }
            _state.update {
                it.copy(
                    busy = false,
                    message = result.fold(
                        { (n, notes) -> "Exported $n bytes as ${format.label}." + if (notes.isNotBlank()) "\nEngine notes: $notes" else "" },
                        { e -> "Export failed: ${describe(e)}" },
                    ),
                )
            }
        }
    }

    // ---- Engine probe: try the full PhotoCraft engine from inside the app ----

    /** Loads the currently opened file into the engine session and shows the engine's rendering. */
    fun engineLoad() = engineTask("Loading into the engine...") {
        val bytes = sourceBytes ?: throw IllegalStateException("Open an image first.")
        EngineSession.open(bytes, sourceName)
        val bitmap = EngineSession.renderBitmap()
        EngineResult("Loaded into the engine: ${bitmap.width}x${bitmap.height}.", bitmap)
    }

    /** Lists engine commands whose id or label contains [query] (all, counted, when empty). */
    fun engineFind(query: String) = engineTask("Reading the command list...") {
        val all = JSONArray(EngineSession.commandsJson())
        val q = query.trim().lowercase()
        val lines = ArrayList<String>()
        var matches = 0
        for (i in 0 until all.length()) {
            val c = all.getJSONObject(i)
            val id = c.optString("id")
            val label = c.optString("label")
            if (q.isEmpty() || id.lowercase().contains(q) || label.lowercase().contains(q)) {
                matches++
                if (lines.size < 15) lines += "$id  ($label)\n    params: ${c.optString("params").take(220)}"
            }
        }
        EngineResult("${all.length()} commands in total, $matches match.\n" + lines.joinToString("\n"), null)
    }

    /** Runs one engine command and, if a document is loaded, refreshes the preview. */
    fun engineRun(commandId: String, paramsJson: String) = engineTask("Running $commandId...") {
        val result = EngineSession.execute(commandId.trim(), paramsJson)
        val bitmap = runCatching { EngineSession.renderBitmap() }.getOrNull()
        EngineResult("$commandId -> ${result.take(3000)}", bitmap)
    }

    private class EngineResult(val text: String, val bitmap: Bitmap?)

    private fun engineTask(busyText: String, block: () -> EngineResult) {
        if (_state.value.busy) return
        _state.update { it.copy(busy = true, message = null, engineOutput = busyText) }
        viewModelScope.launch {
            runCatching { withContext(Dispatchers.Default) { block() } }
                .onSuccess { r ->
                    _state.update {
                        it.copy(
                            busy = false,
                            engineOutput = r.text,
                            bitmap = r.bitmap ?: it.bitmap,
                            engineActive = it.engineActive || r.bitmap != null,
                        )
                    }
                }
                .onFailure { e -> _state.update { it.copy(busy = false, engineOutput = "Error: ${describe(e)}") } }
        }
    }

    private fun load(uri: Uri): Loaded {
        val name = displayName(uri) ?: "image"
        val bytes = readCapped(uri)

        // Cheap header-only check with Android's decoder before any big allocation.
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw IllegalArgumentException("This does not look like a PNG or JPEG image.")
        }
        if (bounds.outWidth > MAX_SIDE || bounds.outHeight > MAX_SIDE) {
            throw IllegalArgumentException("Image is ${bounds.outWidth}x${bounds.outHeight}; the prototype shows at most $MAX_SIDE px per side.")
        }
        if (bounds.outWidth.toLong() * bounds.outHeight > NativeBridge.nativeMaxPixels()) {
            throw IllegalArgumentException("Image is too large for the prototype (limit ${NativeBridge.nativeMaxPixels()} pixels).")
        }

        val img = NativeImage.open(bytes, name)
        try {
            val buffer = ByteBuffer.allocateDirect(img.pixelBufferSize)
            img.renderPremultiplied(buffer)
            buffer.rewind()
            val bitmap = Bitmap.createBitmap(img.width, img.height, Bitmap.Config.ARGB_8888)
            bitmap.copyPixelsFromBuffer(buffer)
            val engine = runCatching { EngineSession.isAvailable() }.getOrDefault(false)
            return Loaded(img, bitmap, "$name - ${img.width}x${img.height} - native ABI ${NativeBridge.EXPECTED_ABI_VERSION}", bytes, name, engine)
        } catch (t: Throwable) {
            img.close()
            throw t
        }
    }

    private fun readCapped(uri: Uri): ByteArray {
        val input = resolver.openInputStream(uri) ?: throw IOException("could not open the selected file")
        input.use { stream ->
            val out = ByteArrayOutputStream()
            val chunk = ByteArray(64 * 1024)
            while (true) {
                val n = stream.read(chunk)
                if (n < 0) break
                out.write(chunk, 0, n)
                if (out.size() > MAX_FILE_BYTES) throw IllegalArgumentException("File is larger than ${MAX_FILE_BYTES / (1024 * 1024)} MiB.")
            }
            return out.toByteArray()
        }
    }

    private fun displayName(uri: Uri): String? =
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }

    private fun describe(e: Throwable): String = when (e) {
        is OutOfMemoryError -> "Not enough memory to process this image."
        is NativeException -> e.message ?: "Native engine error."
        is UnsatisfiedLinkError -> "The native library could not be loaded: ${e.message}"
        is ExceptionInInitializerError -> "The native library failed to initialise: ${e.cause?.message ?: e.message}"
        is IOException, is IllegalArgumentException -> e.message ?: e.javaClass.simpleName
        else -> "${e.javaClass.simpleName}: ${e.message}"
    }

    override fun onCleared() {
        image?.close()
        image = null
    }

    private companion object {
        const val MAX_FILE_BYTES = 64 * 1024 * 1024
        const val MAX_SIDE = 8192
    }
}
