package dev.pixelstudio.app.bridge

import android.graphics.Bitmap
import java.nio.ByteBuffer

/** Thin wrapper over the engine entry points of [NativeBridge]. Call from a background thread. */
object EngineSession {
    fun isAvailable(): Boolean = NativeBridge.nativeEngineAvailable()

    fun open(bytes: ByteArray, name: String) = NativeBridge.nativeEngineOpen(bytes, name)

    fun execute(commandId: String, paramsJson: String): String = NativeBridge.nativeEngineExecute(commandId, paramsJson)

    fun commandsJson(): String = NativeBridge.nativeEngineCommands()

    fun exportPng(): ByteArray = NativeBridge.nativeEngineExportPng()

    fun exportJpeg(quality: Int): ByteArray = NativeBridge.nativeEngineExportJpeg(quality)

    /** Renders the engine's active document into a new ARGB_8888 bitmap (premultiplied, stride = width * 4). */
    fun renderBitmap(): Bitmap {
        val w = NativeBridge.nativeEngineWidth()
        val h = NativeBridge.nativeEngineHeight()
        val buffer = ByteBuffer.allocateDirect(w * h * 4)
        NativeBridge.nativeEngineRender(buffer)
        buffer.rewind()
        return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { it.copyPixelsFromBuffer(buffer) }
    }
}
