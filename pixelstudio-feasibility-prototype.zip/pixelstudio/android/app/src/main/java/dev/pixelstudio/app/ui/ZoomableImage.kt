package dev.pixelstudio.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize

/**
 * Shows [bitmap] fitted in its container with pinch-zoom, drag-pan and double-tap (fit <-> 1:1).
 * The maths lives in [ViewTransform]. [onScaleChanged] reports pixels-on-screen per image pixel.
 */
@Composable
fun ZoomableImage(bitmap: Bitmap, modifier: Modifier = Modifier, onScaleChanged: (Float) -> Unit = {}) {
    var transform by remember(bitmap) { mutableStateOf(ViewTransform()) }
    var container by remember { mutableStateOf(IntSize.Zero) }
    val imageBitmap = remember(bitmap) { bitmap.asImageBitmap() }
    val iw = bitmap.width.toFloat()
    val ih = bitmap.height.toFloat()
    val scale = transform.actualScale(container.width.toFloat(), container.height.toFloat(), iw, ih)

    LaunchedEffect(scale) { onScaleChanged(scale) }

    Box(
        modifier = modifier
            .clipToBounds()
            .onSizeChanged {
                container = it
                transform = transform.clamped(it.width.toFloat(), it.height.toFloat(), iw, ih)
            }
            .pointerInput(bitmap) {
                detectTransformGestures { centroid, pan, zoomChange, _ ->
                    transform = transform.transformed(
                        centroid.x, centroid.y, pan.x, pan.y, zoomChange,
                        size.width.toFloat(), size.height.toFloat(), iw, ih,
                    )
                }
            }
            .pointerInput(bitmap) {
                detectTapGestures(
                    onDoubleTap = { p ->
                        transform = transform.doubleTapped(p.x, p.y, size.width.toFloat(), size.height.toFloat(), iw, ih)
                    },
                )
            },
    ) {
        Image(
            bitmap = imageBitmap,
            contentDescription = "Image processed by the native engine",
            contentScale = ContentScale.Fit,
            // Show hard pixels once zoomed in far enough to see them.
            filterQuality = if (scale >= 2f) FilterQuality.None else FilterQuality.Low,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = transform.zoom
                    scaleY = transform.zoom
                    translationX = transform.offsetX
                    translationY = transform.offsetY
                },
        )
    }
}
