package dev.pixelstudio.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.pixelstudio.app.CropAspect
import dev.pixelstudio.app.ExportFormat
import dev.pixelstudio.app.MainViewModel
import dev.pixelstudio.app.Tool
import dev.pixelstudio.app.UiState
import kotlin.math.roundToInt

@Composable
fun PixelStudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(), content = content)
}

@Composable
fun EditorScreen(vm: MainViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    var scale by remember { mutableFloatStateOf(0f) }
    var exportMenu by remember { mutableStateOf(false) }

    // A null result means the user cancelled the picker; nothing to do.
    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.openImage(uri)
    }
    val savePng = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) vm.exportTo(uri, ExportFormat.PNG)
    }
    val saveJpeg = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/jpeg")) { uri ->
        if (uri != null) vm.exportTo(uri, ExportFormat.JPEG)
    }
    val openImage = { openLauncher.launch(arrayOf("image/png", "image/jpeg")) }
    val canAct = state.canExport && !state.busy

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(modifier = Modifier.safeDrawingPadding()) {
            // ---- top bar
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = openImage, enabled = !state.busy) { Text("Open") }
                Row {
                    TextButton(onClick = vm::undo, enabled = canAct && state.engineActive) { Text("Undo") }
                    TextButton(onClick = vm::redo, enabled = canAct && state.engineActive) { Text("Redo") }
                }
                Box {
                    TextButton(onClick = { exportMenu = true }, enabled = canAct) { Text("Export") }
                    DropdownMenu(expanded = exportMenu, onDismissRequest = { exportMenu = false }) {
                        DropdownMenuItem(text = { Text("PNG") }, onClick = {
                            exportMenu = false
                            savePng.launch("pixelstudio-export.png")
                        })
                        for (q in listOf(95, 85, 70)) {
                            DropdownMenuItem(text = { Text("JPEG, quality $q") }, onClick = {
                                exportMenu = false
                                vm.setJpegQuality(q)
                                saveJpeg.launch("pixelstudio-export.jpg")
                            })
                        }
                    }
                }
            }
            if (state.busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            state.message?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp))
            }

            // ---- canvas / console
            val bitmap = state.bitmap
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                when {
                    state.tool == Tool.CONSOLE -> ConsolePanel(state, vm, Modifier.fillMaxSize().padding(horizontal = 12.dp))
                    bitmap == null -> Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("PixelStudio", style = MaterialTheme.typography.headlineMedium)
                        Text("Open a PNG or JPEG to start editing.", style = MaterialTheme.typography.bodyMedium)
                        Button(onClick = openImage, enabled = !state.busy) { Text("Open image") }
                    }
                    else -> {
                        val iw = bitmap.width.toFloat()
                        val ih = bitmap.height.toFloat()
                        ZoomableImage(
                            bitmap = bitmap,
                            modifier = Modifier.fillMaxSize(),
                            onScaleChanged = { scale = it },
                            overlay = { transform ->
                                val crop = state.crop
                                if (state.tool == Tool.CROP && crop != null) {
                                    CropOverlay(
                                        box = crop,
                                        transform = transform,
                                        imageWidth = iw,
                                        imageHeight = ih,
                                        aspectLocked = state.cropAspect.ratio != null,
                                        onDrag = vm::cropDrag,
                                    )
                                }
                            },
                        )
                    }
                }
            }

            // ---- status line + tool settings
            if (bitmap != null && state.tool != Tool.CONSOLE) {
                Text(
                    "${state.name ?: "image"}  ${bitmap.width}x${bitmap.height}  zoom ${(scale * 100).roundToInt()}%  (pinch, drag, double-tap)",
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
                )
            }
            val crop = state.crop
            if (state.tool == Tool.CROP && crop != null) {
                CropSettings(state, vm, "${crop.toRect().width} x ${crop.toRect().height} px")
            }

            // ---- bottom toolbar
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ToolButton("View", state.tool == Tool.VIEW, Modifier.weight(1f)) { vm.setTool(Tool.VIEW) }
                ToolButton("Crop", state.tool == Tool.CROP, Modifier.weight(1f)) { vm.setTool(Tool.CROP) }
                ToolButton("Console", state.tool == Tool.CONSOLE, Modifier.weight(1f)) { vm.setTool(Tool.CONSOLE) }
            }
        }
    }
}

@Composable
private fun ToolButton(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    if (selected) FilledTonalButton(onClick = onClick, modifier = modifier) { Text(label) }
    else TextButton(onClick = onClick, modifier = modifier) { Text(label) }
}

@Composable
private fun CropSettings(state: UiState, vm: MainViewModel, sizeText: String) {
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (a in CropAspect.entries) {
                FilterChip(selected = state.cropAspect == a, onClick = { vm.setCropAspect(a) }, label = { Text(a.label) })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text(sizeText, style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.setTool(Tool.VIEW) }, enabled = !state.busy) { Text("Cancel") }
                Button(onClick = vm::applyCrop, enabled = !state.busy) { Text("Apply crop") }
            }
        }
    }
}

/** Developer console for the engine's full command set (search, run by id with JSON params). */
@Composable
private fun ConsolePanel(state: UiState, vm: MainViewModel, modifier: Modifier = Modifier) {
    var query by remember { mutableStateOf("") }
    var commandId by remember { mutableStateOf("image.crop") }
    var params by remember { mutableStateOf("{\"x\":0,\"y\":0,\"width\":100,\"height\":100}") }
    val ready = state.canExport && !state.busy && state.engineAvailable
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            if (state.engineAvailable) "Full native engine: available in this build." else "This APK was built without the full engine (base build).",
            style = MaterialTheme.typography.bodyMedium,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Search commands") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedButton(onClick = { vm.consoleFind(query) }, enabled = !state.busy && state.engineAvailable) { Text("Find") }
        }
        OutlinedTextField(value = commandId, onValueChange = { commandId = it }, label = { Text("Command id") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = params, onValueChange = { params = it }, label = { Text("Params (JSON)") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { vm.consoleRun(commandId, params) }, enabled = ready) { Text("Run command") }
        SelectionContainer(modifier = Modifier.weight(1f).fillMaxWidth()) {
            Text(
                state.engineOutput.ifEmpty { "Output appears here." },
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp),
                modifier = Modifier.verticalScroll(rememberScrollState()),
            )
        }
    }
}
