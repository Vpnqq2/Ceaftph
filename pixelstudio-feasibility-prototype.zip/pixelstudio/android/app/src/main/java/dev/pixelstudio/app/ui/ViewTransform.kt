package dev.pixelstudio.app.ui

import kotlin.math.max
import kotlin.math.min

/**
 * Zoom/pan state for showing an image of size (iw, ih) inside a container of size (cw, ch).
 * Pure Kotlin (no Android types) so it is unit-tested on the JVM.
 *
 * Model: the image is first scaled to fit the container ("fit scale") and centred; [zoom] multiplies
 * that (1 = fit, up to [MAX_ZOOM]); [offsetX]/[offsetY] translate it in screen pixels relative to the
 * centred position. Screen coordinates are relative to the container's top-left corner.
 *
 * `screenToImage` is the mapping later tools (brush, crop) will use for touch -> pixel coordinates.
 */
data class ViewTransform(
    val zoom: Float = 1f,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
) {
    /** Pinch/pan step. ([focusX],[focusY]) is the gesture centroid; the image point under it stays put. */
    fun transformed(
        focusX: Float, focusY: Float, panX: Float, panY: Float, zoomChange: Float,
        cw: Float, ch: Float, iw: Float, ih: Float,
    ): ViewTransform {
        if (!valid(cw, ch, iw, ih) || zoomChange <= 0f || !zoomChange.isFinite()) return this
        val newZoom = (zoom * zoomChange).coerceIn(MIN_ZOOM, MAX_ZOOM)
        val k = newZoom / zoom
        val fx = focusX - cw / 2f
        val fy = focusY - ch / 2f
        val ox = fx - (fx - offsetX) * k + panX
        val oy = fy - (fy - offsetY) * k + panY
        return ViewTransform(newZoom, ox, oy).clamped(cw, ch, iw, ih)
    }

    /** Double tap: back to fit if zoomed in, otherwise to 1:1 pixels (at least 2x fit) around the tap. */
    fun doubleTapped(focusX: Float, focusY: Float, cw: Float, ch: Float, iw: Float, ih: Float): ViewTransform {
        if (!valid(cw, ch, iw, ih)) return this
        if (zoom > 1.01f) return ViewTransform()
        val target = max(2f, 1f / fitScale(cw, ch, iw, ih)).coerceAtMost(MAX_ZOOM)
        return transformed(focusX, focusY, 0f, 0f, target / zoom, cw, ch, iw, ih)
    }

    /** Keeps the image from being dragged away; an axis that fits inside the container stays centred. */
    fun clamped(cw: Float, ch: Float, iw: Float, ih: Float): ViewTransform {
        if (!valid(cw, ch, iw, ih)) return this
        val s = fitScale(cw, ch, iw, ih) * zoom
        val maxX = max(0f, (iw * s - cw) / 2f)
        val maxY = max(0f, (ih * s - ch) / 2f)
        return copy(offsetX = offsetX.coerceIn(-maxX, maxX), offsetY = offsetY.coerceIn(-maxY, maxY))
    }

    /** Pixels on screen per image pixel (1.0 = 100%). */
    fun actualScale(cw: Float, ch: Float, iw: Float, ih: Float): Float =
        if (valid(cw, ch, iw, ih)) fitScale(cw, ch, iw, ih) * zoom else 0f

    fun screenToImage(x: Float, y: Float, cw: Float, ch: Float, iw: Float, ih: Float): Pair<Float, Float> {
        val s = actualScale(cw, ch, iw, ih)
        if (s <= 0f) return 0f to 0f
        return ((x - cw / 2f - offsetX) / s + iw / 2f) to ((y - ch / 2f - offsetY) / s + ih / 2f)
    }

    fun imageToScreen(x: Float, y: Float, cw: Float, ch: Float, iw: Float, ih: Float): Pair<Float, Float> {
        val s = actualScale(cw, ch, iw, ih)
        return ((x - iw / 2f) * s + cw / 2f + offsetX) to ((y - ih / 2f) * s + ch / 2f + offsetY)
    }

    companion object {
        const val MIN_ZOOM = 1f
        const val MAX_ZOOM = 16f

        fun fitScale(cw: Float, ch: Float, iw: Float, ih: Float): Float = min(cw / iw, ch / ih)

        private fun valid(cw: Float, ch: Float, iw: Float, ih: Float) = cw > 0f && ch > 0f && iw > 0f && ih > 0f
    }
}
