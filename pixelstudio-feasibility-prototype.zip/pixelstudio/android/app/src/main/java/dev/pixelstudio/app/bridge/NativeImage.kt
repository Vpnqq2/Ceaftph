package dev.pixelstudio.app.bridge

import java.nio.ByteBuffer

/** One document held by the native engine. Close it when done; closing twice is harmless. */
class NativeImage private constructor(
    private var handle: Long,
    val width: Int,
    val height: Int,
) : AutoCloseable {

    /** Bytes [renderPremultiplied] needs: tightly packed RGBA8, stride = width * 4. */
    val pixelBufferSize: Int get() = width * height * 4

    @Synchronized
    fun renderPremultiplied(dst: ByteBuffer) {
        require(dst.isDirect) { "destination must be a direct ByteBuffer" }
        require(dst.capacity() >= pixelBufferSize) { "destination too small" }
        NativeBridge.nativeRenderPremultiplied(live(), dst)
    }

    @Synchronized
    fun exportPng(): ByteArray = NativeBridge.nativeExportPng(live())

    /** [quality] must be 1..=100. Call [lastExportWarnings] right after for the engine's notes. */
    @Synchronized
    fun exportJpeg(quality: Int): ByteArray = NativeBridge.nativeExportJpeg(live(), quality)

    /** Warnings from the most recent export (any format); empty string if none. */
    fun lastExportWarnings(): String = NativeBridge.nativeLastExportWarnings()

    @Synchronized
    override fun close() {
        if (handle != 0L) {
            NativeBridge.nativeClose(handle)
            handle = 0L
        }
    }

    private fun live(): Long = handle.also { check(it != 0L) { "NativeImage is closed" } }

    companion object {
        fun open(bytes: ByteArray, name: String): NativeImage {
            val handle = NativeBridge.nativeOpen(bytes, name)
            try {
                return NativeImage(handle, NativeBridge.nativeWidth(handle), NativeBridge.nativeHeight(handle))
            } catch (t: Throwable) {
                NativeBridge.nativeClose(handle)
                throw t
            }
        }
    }
}
