package dev.pixelstudio.app.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Test

/** Plain JVM tests for the zoom/pan maths. Expected numbers were cross-checked with an independent Python mirror. */
class ViewTransformTest {
    private val d = 0.001f
    private val start = ViewTransform()

    @Test
    fun fitScaleUsesTheLimitingAxis() {
        assertEquals(2f, ViewTransform.fitScale(1000f, 2000f, 500f, 500f), d)
        assertEquals(0.25f, ViewTransform.fitScale(1000f, 1000f, 4000f, 2000f), d)
    }

    @Test
    fun defaultTransformCentresTheImage() {
        // 500x500 image in a 1000x2000 container: shown 1000x1000, vertically centred (y 500..1500).
        val (x0, y0) = start.screenToImage(0f, 500f, 1000f, 2000f, 500f, 500f)
        val (x1, y1) = start.screenToImage(1000f, 1500f, 1000f, 2000f, 500f, 500f)
        val (cx, cy) = start.screenToImage(500f, 1000f, 1000f, 2000f, 500f, 500f)
        assertEquals(0f, x0, d); assertEquals(0f, y0, d)
        assertEquals(500f, x1, d); assertEquals(500f, y1, d)
        assertEquals(250f, cx, d); assertEquals(250f, cy, d)
    }

    @Test
    fun screenAndImageMappingsRoundTrip() {
        val t = ViewTransform(3f, 120f, -40f)
        val (ix, iy) = t.screenToImage(321f, 654f, 1000f, 2000f, 800f, 600f)
        val (sx, sy) = t.imageToScreen(ix, iy, 1000f, 2000f, 800f, 600f)
        assertEquals(321f, sx, d)
        assertEquals(654f, sy, d)
    }

    @Test
    fun zoomingKeepsTheImagePointUnderTheFocus() {
        val t = start.transformed(800f, 300f, 0f, 0f, 2f, 1000f, 1000f, 1000f, 1000f)
        assertEquals(2f, t.zoom, d)
        assertEquals(-300f, t.offsetX, d)
        assertEquals(200f, t.offsetY, d)
        val (ix, iy) = t.screenToImage(800f, 300f, 1000f, 1000f, 1000f, 1000f)
        assertEquals(800f, ix, d)
        assertEquals(300f, iy, d)
    }

    @Test
    fun panningIsClampedToTheImageEdges() {
        val zoomed = ViewTransform(2f, -300f, 200f)
        val t = zoomed.transformed(500f, 500f, 10_000f, 0f, 1f, 1000f, 1000f, 1000f, 1000f)
        assertEquals(500f, t.offsetX, d) // (2000 - 1000) / 2
        assertEquals(200f, t.offsetY, d)
    }

    @Test
    fun zoomIsLimitedAndFitResetsOffsets() {
        val max = start.transformed(500f, 500f, 0f, 0f, 100f, 1000f, 1000f, 1000f, 1000f)
        assertEquals(ViewTransform.MAX_ZOOM, max.zoom, d)
        val min = ViewTransform(2f, -300f, 200f).transformed(500f, 500f, 0f, 0f, 0.01f, 1000f, 1000f, 1000f, 1000f)
        assertEquals(1f, min.zoom, d)
        assertEquals(0f, min.offsetX, d)
        assertEquals(0f, min.offsetY, d)
    }

    @Test
    fun anAxisThatFitsStaysCentred() {
        // 1000x500 image in 1000x2000: it fits vertically, so a vertical drag does nothing.
        val t = start.transformed(500f, 1000f, 0f, 300f, 1f, 1000f, 2000f, 1000f, 500f)
        assertEquals(0f, t.offsetY, d)
    }

    @Test
    fun doubleTapGoesToOneToOneThenBackToFit() {
        // 4000x4000 image in 1000x1000 container: fit = 0.25, so 1:1 is zoom 4.
        val zoomed = start.doubleTapped(500f, 500f, 1000f, 1000f, 4000f, 4000f)
        assertEquals(4f, zoomed.zoom, d)
        assertEquals(1f, zoomed.actualScale(1000f, 1000f, 4000f, 4000f), d)
        val back = zoomed.doubleTapped(500f, 500f, 1000f, 1000f, 4000f, 4000f)
        assertEquals(ViewTransform(), back)
    }

    @Test
    fun degenerateSizesChangeNothing() {
        assertSame(start, start.transformed(0f, 0f, 5f, 5f, 2f, 0f, 0f, 100f, 100f))
        assertSame(start, start.transformed(0f, 0f, 5f, 5f, Float.NaN, 100f, 100f, 100f, 100f))
        assertSame(start, start.doubleTapped(0f, 0f, 100f, 100f, 0f, 0f))
    }
}
