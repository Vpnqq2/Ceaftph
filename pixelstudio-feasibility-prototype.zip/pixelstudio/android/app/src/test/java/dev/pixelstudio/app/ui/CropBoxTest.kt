package dev.pixelstudio.app.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Test

/** JVM tests. Expected numbers were cross-checked with an independent Python mirror of the formulas. */
class CropBoxTest {
    private val d = 0.01f

    private fun assertBox(l: Float, t: Float, r: Float, b: Float, box: CropBox) {
        assertEquals(l, box.left, d); assertEquals(t, box.top, d)
        assertEquals(r, box.right, d); assertEquals(b, box.bottom, d)
    }

    @Test
    fun fullAndFittedBoxes() {
        assertBox(0f, 0f, 1024f, 1536f, CropBox.full(1024f, 1536f))
        assertBox(0f, 256f, 1024f, 1280f, CropBox.fitted(1f, 1024f, 1536f))
        assertBox(0f, 480f, 1024f, 1056f, CropBox.fitted(16f / 9f, 1024f, 1536f))
        assertBox(80f, 0f, 944f, 1536f, CropBox.fitted(9f / 16f, 1024f, 1536f))
    }

    @Test
    fun movingStopsAtTheImageEdges() {
        val b = CropBox(100f, 100f, 300f, 200f)
        assertBox(0f, 110f, 200f, 210f, b.moved(-500f, 10f, 1000f, 800f))
        assertBox(800f, 700f, 1000f, 800f, b.moved(5000f, 5000f, 1000f, 800f))
    }

    @Test
    fun freeResizeClampsToImageAndMinimumSize() {
        val b = CropBox(100f, 100f, 300f, 200f)
        assertBox(100f, 100f, 350f, 170f, b.resized(CropHandle.BOTTOM_RIGHT, 50f, -30f, 1000f, 800f))
        assertBox(0f, 0f, 300f, 200f, b.resized(CropHandle.TOP_LEFT, -500f, -500f, 1000f, 800f))
        assertBox(284f, 100f, 300f, 200f, b.resized(CropHandle.LEFT, 1000f, 0f, 1000f, 800f))
        assertBox(100f, 100f, 300f, 800f, b.resized(CropHandle.BOTTOM, 0f, 10000f, 1000f, 800f))
        assertBox(100f, 100f, 116f, 200f, b.resized(CropHandle.RIGHT, -1000f, 0f, 1000f, 800f))
    }

    @Test
    fun lockedAspectResizesCornersAroundTheOppositeCorner() {
        val sq = CropBox(100f, 100f, 300f, 300f)
        assertBox(100f, 100f, 400f, 400f, sq.resized(CropHandle.BOTTOM_RIGHT, 100f, 0f, 1000f, 1000f, 1f))
        assertBox(50f, 50f, 300f, 300f, sq.resized(CropHandle.TOP_LEFT, -50f, 0f, 1000f, 1000f, 1f))
        assertBox(0f, 0f, 300f, 300f, sq.resized(CropHandle.TOP_LEFT, -500f, 0f, 1000f, 1000f, 1f))
    }

    @Test
    fun lockedAspectIgnoresEdgeHandles() {
        val sq = CropBox(100f, 100f, 300f, 300f)
        assertSame(sq, sq.resized(CropHandle.TOP, 0f, -50f, 1000f, 1000f, 1f))
    }

    @Test
    fun roundsToWholePixels() {
        val r = CropBox(10.4f, 20.6f, 110.4f, 120.2f).toRect()
        assertEquals(CropRect(10, 21, 100, 99), r)
    }

    @Test
    fun hitTestPrefersCornersThenEdgesThenBody() {
        fun hit(x: Float, y: Float, edges: Boolean = true) = CropBox.hit(100f, 100f, 500f, 400f, x, y, 30f, edges)
        assertEquals(CropHandle.TOP_LEFT, hit(102f, 98f))
        assertEquals(CropHandle.BOTTOM_RIGHT, hit(500f, 400f))
        assertEquals(CropHandle.TOP, hit(300f, 105f))
        assertEquals(CropHandle.RIGHT, hit(498f, 250f))
        assertEquals(CropHandle.BODY, hit(300f, 250f))
        assertEquals(CropHandle.TOP_LEFT, hit(110f, 105f))
        assertEquals(CropHandle.BODY, hit(300f, 105f, edges = false))
        assertNull(hit(300f, 500f))
    }
}
