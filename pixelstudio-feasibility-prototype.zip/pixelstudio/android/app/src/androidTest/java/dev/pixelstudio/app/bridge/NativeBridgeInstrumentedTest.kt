package dev.pixelstudio.app.bridge

import android.util.Base64
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import org.junit.runner.RunWith
import java.nio.ByteBuffer

/** Runs on a device/emulator against the real libpixelstudio_bridge.so. */
@RunWith(AndroidJUnit4::class)
class NativeBridgeInstrumentedTest {
    // 2x2 RGBA PNG: red, green / blue, white at alpha 128 (same bytes as the Rust test fixture).
    private val png = Base64.decode("iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAYAAABytg0kAAAAE0lEQVR4nGP4z8DwHwyBNAg0AABJSQl4KKDbdwAAAABJRU5ErkJggg==", Base64.DEFAULT)

    @Test
    fun abiVersionMatches() {
        assertEquals(NativeBridge.EXPECTED_ABI_VERSION, NativeBridge.nativeAbiVersion())
    }

    @Test
    fun importRenderExport() {
        NativeImage.open(png, "rgba_2x2.png").use { img ->
            assertEquals(2, img.width)
            assertEquals(2, img.height)
            val buffer = ByteBuffer.allocateDirect(img.pixelBufferSize)
            img.renderPremultiplied(buffer)
            val px = ByteArray(16)
            buffer.rewind()
            buffer.get(px)
            assertEquals(listOf<Byte>(-1, 0, 0, -1), px.slice(0..3))
            assertEquals(listOf<Byte>(0, -1, 0, -1), px.slice(4..7))
            assertEquals(listOf<Byte>(0, 0, -1, -1), px.slice(8..11))
            val out = img.exportPng()
            assertEquals(0x89.toByte(), out[0])
            assertEquals('P'.code.toByte(), out[1])
        }
    }

    @Test
    fun exportJpegProducesAJpegAndValidatesQuality() {
        NativeImage.open(png, "rgba_2x2.png").use { img ->
            val jpg = img.exportJpeg(85)
            assertEquals(0xFF.toByte(), jpg[0])
            assertEquals(0xD8.toByte(), jpg[1])
            img.lastExportWarnings() // must not throw; content is engine-defined
            assertThrows(NativeException::class.java) { img.exportJpeg(0) }
            assertThrows(NativeException::class.java) { img.exportJpeg(101) }
        }
    }

    @Test
    fun garbageInputThrowsNativeException() {
        assertThrows(NativeException::class.java) { NativeImage.open("not an image".toByteArray(), "x.png") }
    }

    @Test
    fun unknownHandleThrowsNativeException() {
        assertThrows(NativeException::class.java) { NativeBridge.nativeWidth(123_456_789L) }
    }

    @Test
    fun useAfterCloseIsRejected() {
        val img = NativeImage.open(png, "a.png")
        img.close()
        img.close() // harmless
        assertThrows(IllegalStateException::class.java) { img.exportPng() }
    }
}
