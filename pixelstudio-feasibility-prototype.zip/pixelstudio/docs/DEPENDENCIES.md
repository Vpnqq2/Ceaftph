# Dependencies and vendoring

Static analysis of upstream's `Cargo.lock` with `scripts/lock_closure.py` (roots: `photocraft-io`,
`photocraft-compose`, `photocraft-doc`):

- 374 packages in the lockfile closure (all platforms, includes dev-dependencies, so an over-count).
- **Git-sourced: 2 packages, one repository, one revision**
  - `craft-docpath 0.1.0` (used by `photocraft-io`)
  - `craft-jpeg 0.1.0` (used by `photocraft-codecs`)
  - repo `https://github.com/storytold/craft-libs`, rev `92d392cff132eaf53e13afff77f38b5c11b73aa0`
- Not in the closure (so they need no vendoring for this milestone): egui, winit, winprint, wgpu, `craft-print`,
  `craft-ui`, `craft-update`. Upstream's `[patch]` entries for egui/winit do not apply to `native/`.
- Other crates in the bridge itself: `jni =0.21.1` (+ its dependencies) from crates.io.
- Cross-compile watch list: `yeslogic-fontconfig-sys` (probably Linux-gated, unverified), `cc`/`pkg-config`
  (build-script C compilation under cargo-ndk), `fontdb`/`resvg` with `system-fonts`, `craft-docpath` (ICU data, size).

## Not verified
- That the git repository is reachable for you (public vs private).
- Any offline build. **Offline reproducibility is not claimed.**

## Vendoring recipe (untested)
```bash
cd native
mkdir -p .cargo
cargo vendor vendor > .cargo/config.toml      # downloads every registry crate AND the craft-libs git checkout
cargo test -p photocraft-android-bridge --offline --locked   # prove it works without network
```
`cargo vendor` covers registry and git sources; the upstream checkout (path dependencies) is not vendored, keep it
alongside. Vendored sources span all platforms (hundreds of MB likely); `native/vendor/` is git-ignored by default,
decide whether to commit it or archive it. Gradle/AGP, the Android SDK and the NDK are separate downloads and are
not covered by this.

## Re-checking
`cargo tree --target aarch64-linux-android -p photocraft-android-bridge` after the first build is the authoritative list.
