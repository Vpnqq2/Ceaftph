# Kotlin <-> Rust interface (ABI version 2)

Status: designed against verified upstream signatures; **uncompiled**.

## Layers
`NativeBridge` (raw `external` functions) <- `NativeImage` (owns a handle, `AutoCloseable`) <- `MainViewModel`.
Rust: `jni_glue.rs` (only `unsafe`) -> `bridge_core.rs` (safe, host-testable) -> `photocraft-io` / `photocraft-compose`.

## Handles and ownership
- A document is identified by a `Long` handle: a never-reused counter value, not a pointer. 0 is never valid.
  A stale or forged handle gives a `NativeException`, not undefined behaviour.
- The registry (`Mutex<HashMap<u64, Arc<Document>>>`) owns every document. Kotlin owns only the handle and
  must call `close()` (`NativeImage` does; the ViewModel closes on replace and in `onCleared`). Closing twice is harmless.
- Calls take an `Arc` clone and release the registry lock before heavy work, so a concurrent `close` cannot free a
  document mid-render.

## Pixel buffer contract (`nativeRenderPremultiplied`)
- Kotlin allocates a **direct** `ByteBuffer` of at least `width * height * 4` bytes and keeps it referenced and
  untouched until the call returns. Rust writes into it; Rust never keeps the pointer.
- Position and limit are ignored; capacity bounds the write. Bytes past `width * height * 4` are not modified.
- Format: RGBA, 8 bits per channel, byte order R,G,B,A, **premultiplied alpha**, top row first.
- Row stride: exactly `width * 4` (no padding). This matches `Bitmap.Config.ARGB_8888` memory on little-endian
  Android ABIs (arm64-v8a, x86_64), so `Bitmap.copyPixelsFromBuffer` needs no per-pixel work.
- Source: `photocraft_compose::flatten` gives straight-alpha f32 RGBA; `Buffer::to_rgba8` quantises to straight RGBA8;
  `bridge_core::render_premultiplied` then premultiplies with rounding `(c*a + 127) / 255`.

## Other data
- `nativeOpen(bytes, name)`: the file bytes are copied once into Rust (`convert_byte_array`); `name` is the display
  name passed to the importer.
- `nativeExportPng`: exports the document via `photocraft_io::export(..., "export.png", default options)`; the bytes
  come back as a new Java `byte[]` owned by the JVM. PNG stores straight alpha; no premultiplication is involved.

## Export functions (ABI 2)
- `nativeExportPng(handle)` and `nativeExportJpeg(handle, quality)` (quality 1..=100, otherwise `NativeException`)
  return the encoded file as a new Java `byte[]`. Both call `photocraft_io::export` with default options except
  `encode.jpeg_quality`; file names `export.png` / `export.jpg` select the codec.
- `nativeLastExportWarnings()` returns the exporter's warnings for the latest export, one per line (empty if none).
  It is a single process-wide slot: the app runs one export at a time and reads it right after the export returns.
- JPEG drops alpha; the exporter warns when transparent pixels are discarded.

## Errors
Every entry point runs under `catch_unwind`. Failures become a thrown
`dev.pixelstudio.app.bridge.NativeException` with a readable message (`BridgeError`: empty input, import failure, too
large, invalid handle, invalid argument, buffer too small, render failure, export failure, JNI error); panics become
`NativeException("native panic: ...")`. `panic = "unwind"` must stay set in the release profile. Kotlin-side
precondition failures raise `IllegalArgumentException` / `IllegalStateException`.

## JNI registration
Dynamic lookup by symbol name: `Java_dev_pixelstudio_app_bridge_NativeBridge_<method>`, exported with
`#[unsafe(no_mangle)] extern "system"`. No `JNI_OnLoad` or `RegisterNatives` table. The Kotlin functions are
`@JvmStatic external` in an `object`, hence the `JClass` receiver. Renaming the package or class requires changing
every symbol; with R8 enabled, keep `dev.pixelstudio.app.bridge.NativeBridge`.
`System.loadLibrary("pixelstudio_bridge")` is followed by an ABI-version check (`EXPECTED_ABI_VERSION` vs
`ABI_VERSION` in `bridge_core.rs`); bump both on any contract change.

## Threading
Rust is called from `Dispatchers.Default` / `Dispatchers.IO`, never the main thread. `NativeImage` methods are
`@Synchronized`. `flatten` uses rayon internally.

## Limits
`MAX_PIXELS = 12_000_000` (Rust, exposed via `nativeMaxPixels`), 64 MiB input file, 8192 px per side (Kotlin).
