//! The real PhotoCraft engine, behind `--features engine`.
//!
//! `photocraft_engine::Session` is a single-threaded, mutable editing session. It lives on ONE
//! dedicated worker thread that creates it (so `Session` never has to be `Send`); callers send
//! closures to that thread and wait for the reply. This also keeps engine work off the Android
//! main thread and serialises all edits.
//!
//! Engine calls used (all confirmed in the upstream source):
//!   Session::new() / add_document(Document, Option<String>) -> usize (also makes it active)
//!   Session::execute(&mut self, id: &str, params: serde_json::Value) -> Result<Value>
//!   Session::active() -> Option<&DocState>;  DocState.doc: Arc<Document>
//!   photocraft_engine::cmd::command_specs() -> &'static [CommandSpec]
//!   photocraft_engine::cmd::list_entry(&Session, &CommandSpec, Option<String>) -> Value

use std::any::Any;
use std::panic::{AssertUnwindSafe, catch_unwind};
use std::sync::mpsc::{self, Sender};
use std::sync::{Arc, Mutex, PoisonError};

use photocraft_doc::Document;
use photocraft_engine::Session;

use crate::bridge_core::{self, BridgeError, MAX_PIXELS};

pub const AVAILABLE: bool = true;

type Job = Box<dyn FnOnce(&mut Session) + Send + 'static>;

static WORKER: Mutex<Option<Sender<Job>>> = Mutex::new(None);

fn panic_text(p: &Box<dyn Any + Send>) -> String {
    if let Some(s) = p.downcast_ref::<&str>() {
        (*s).to_string()
    } else if let Some(s) = p.downcast_ref::<String>() {
        s.clone()
    } else {
        "unknown panic".to_string()
    }
}

/// Runs `f` on the session thread (starting it on first use) and returns its result.
fn run<R, F>(f: F) -> Result<R, BridgeError>
where
    R: Send + 'static,
    F: FnOnce(&mut Session) -> Result<R, BridgeError> + Send + 'static,
{
    let (reply_tx, reply_rx) = mpsc::channel::<Result<R, BridgeError>>();
    let job: Job = Box::new(move |session| {
        let out = catch_unwind(AssertUnwindSafe(|| f(session)))
            .unwrap_or_else(|p| Err(BridgeError::Engine(format!("engine panic: {}", panic_text(&p)))));
        let _ = reply_tx.send(out);
    });
    {
        let mut slot = WORKER.lock().unwrap_or_else(PoisonError::into_inner);
        if slot.is_none() {
            let (tx, rx) = mpsc::channel::<Job>();
            std::thread::Builder::new()
                .name("photocraft-session".into())
                .stack_size(32 * 1024 * 1024)
                .spawn(move || {
                    let mut session = Session::new();
                    for job in rx {
                        job(&mut session);
                    }
                })
                .map_err(|e| BridgeError::Engine(format!("cannot start the engine thread: {e}")))?;
            *slot = Some(tx);
        }
        slot.as_ref()
            .expect("worker sender was just installed")
            .send(job)
            .map_err(|_| BridgeError::Engine("the engine thread has stopped".into()))?;
    }
    reply_rx.recv().map_err(|_| BridgeError::Engine("the engine thread has stopped".into()))?
}

/// Decodes the file on the calling thread (the heavy part), then hands the document to the session.
pub fn open_image(bytes: Vec<u8>, name: String) -> Result<(), BridgeError> {
    if bytes.is_empty() {
        return Err(BridgeError::EmptyInput);
    }
    let imported = photocraft_io::import(&name, &bytes).map_err(|e| BridgeError::Import(e.to_string()))?;
    drop(bytes);
    let doc = imported.document;
    let b = doc.bounds();
    let (w, h) = (u64::from(b.width()), u64::from(b.height()));
    if w == 0 || h == 0 {
        return Err(BridgeError::Import("the image has no pixels".into()));
    }
    if w * h > MAX_PIXELS {
        return Err(BridgeError::TooLarge { width: w, height: h });
    }
    run(move |s| {
        s.add_document(doc, None);
        Ok(())
    })
}

/// Runs an engine command (`id` like "image.crop", `params_json` a JSON object or empty) and
/// returns its JSON result as text.
pub fn execute(id: String, params_json: String) -> Result<String, BridgeError> {
    let params: serde_json::Value = if params_json.trim().is_empty() {
        serde_json::json!({})
    } else {
        serde_json::from_str(&params_json).map_err(|e| BridgeError::InvalidArgument(format!("params are not valid JSON: {e}")))?
    };
    run(move |s| s.execute(&id, params).map(|v| v.to_string()).map_err(|e| BridgeError::Engine(e.to_string())))
}

/// Every registered command as a JSON array of {id, label, menu, shortcut, params, ...}. The
/// `enabled` flags are NOT evaluated here (every command is listed as enabled).
pub fn commands_json() -> Result<String, BridgeError> {
    run(|s| {
        let rows: Vec<serde_json::Value> = photocraft_engine::cmd::command_specs()
            .iter()
            .map(|c| photocraft_engine::cmd::list_entry(s, c, None))
            .collect();
        Ok(serde_json::Value::Array(rows).to_string())
    })
}

fn active_doc() -> Result<Arc<Document>, BridgeError> {
    run(|s| {
        s.active()
            .map(|d| Arc::clone(&d.doc))
            .ok_or_else(|| BridgeError::Engine("no active document: load an image into the engine first".into()))
    })
}

pub fn dimensions() -> Result<(u32, u32), BridgeError> {
    let doc = active_doc()?;
    let b = doc.bounds();
    Ok((b.width(), b.height()))
}

/// Flattens the active document into `dst` (premultiplied RGBA8, stride = width * 4); same
/// contract as `bridge_core::render_premultiplied`. The heavy work runs on the caller's thread.
pub fn render_premultiplied(dst: &mut [u8]) -> Result<(u32, u32), BridgeError> {
    let doc = active_doc()?;
    bridge_core::render_doc_premultiplied(&doc, dst)
}

pub fn export_png() -> Result<Vec<u8>, BridgeError> {
    let doc = active_doc()?;
    bridge_core::export_doc(&doc, "export.png", None)
}

pub fn export_jpeg(quality: u8) -> Result<Vec<u8>, BridgeError> {
    bridge_core::check_quality(quality)?;
    let doc = active_doc()?;
    bridge_core::export_doc(&doc, "export.jpg", Some(quality))
}
