//! JNI entry points. Registration is by symbol name (the JVM resolves
//! `Java_<package>_<class>_<method>` with dlsym on first call), so there is no JNI_OnLoad and no
//! RegisterNatives table. The Kotlin side is `dev.pixelstudio.app.bridge.NativeBridge`, an `object`
//! whose `external` functions are `@JvmStatic`, which is why the second parameter is a `JClass`.
//!
//! Rules every entry point follows:
//!   * no panic crosses the FFI boundary: the body runs under `catch_unwind`;
//!   * failures become a thrown `dev.pixelstudio.app.bridge.NativeException`, never a bare error code;
//!   * the only `unsafe` is wrapping the direct ByteBuffer's memory as a slice.

use std::any::Any;
use std::panic::{AssertUnwindSafe, catch_unwind};

use jni::JNIEnv;
use jni::objects::{JByteArray, JByteBuffer, JClass, JString};
use jni::sys::{jboolean, jbyteArray, jint, jlong, jstring};

use crate::bridge_core::{self as ops, BridgeError};

const EXCEPTION_CLASS: &str = "dev/pixelstudio/app/bridge/NativeException";

fn throw(env: &mut JNIEnv, message: &str) {
    // Never stack a second exception on a pending one.
    if env.exception_check().unwrap_or(false) {
        return;
    }
    if env.throw_new(EXCEPTION_CLASS, message).is_err() {
        let _ = env.throw_new("java/lang/RuntimeException", message);
    }
}

fn panic_text(p: &Box<dyn Any + Send>) -> String {
    if let Some(s) = p.downcast_ref::<&str>() {
        (*s).to_string()
    } else if let Some(s) = p.downcast_ref::<String>() {
        s.clone()
    } else {
        "unknown panic".to_string()
    }
}

/// Runs `body`; on error or panic throws a Java exception and returns `fallback`.
fn guarded<'l, T>(env: &mut JNIEnv<'l>, fallback: T, body: impl FnOnce(&mut JNIEnv<'l>) -> Result<T, BridgeError>) -> T {
    match catch_unwind(AssertUnwindSafe(|| body(env))) {
        Ok(Ok(v)) => v,
        Ok(Err(e)) => {
            throw(env, &e.to_string());
            fallback
        }
        Err(p) => {
            throw(env, &format!("native panic: {}", panic_text(&p)));
            fallback
        }
    }
}

fn jni_err(e: jni::errors::Error) -> BridgeError {
    BridgeError::Jni(e.to_string())
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_dev_pixelstudio_app_bridge_NativeBridge_nativeAbiVersion<'l>(_env: JNIEnv<'l>, _class: JClass<'l>) -> jint {
    ops::ABI_VERSION
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_dev_pixelstudio_app_bridge_NativeBridge_nativeMaxPixels<'l>(_env: JNIEnv<'l>, _class: JClass<'l>) -> jlong {
    ops::MAX_PIXELS as jlong
}

/// `nativeOpen(bytes: ByteArray, name: String): Long`. Copies the (compressed) file bytes into Rust.
#[unsafe(no_mangle)]
pub extern "system" fn Java_dev_pixelstudio_app_bridge_NativeBridge_nativeOpen<'l>(
    mut env: JNIEnv<'l>,
    _class: JClass<'l>,
    bytes: JByteArray<'l>,
    name: JString<'l>,
) -> jlong {
    guarded(&mut env, 0, |env| {
        let data = env.convert_byte_array(&bytes).map_err(jni_err)?;
        let name: String = env.get_string(&name).map_err(jni_err)?.into();
        let handle = ops::open_image(&data, &name)?;
        Ok(handle as jlong)
    })
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_dev_pixelstudio_app_bridge_NativeBridge_nativeWidth<'l>(mut env: JNIEnv<'l>, _class: JClass<'l>, handle: jlong) -> jint {
    guarded(&mut env, 0, |_| Ok(ops::dimensions(handle as u64)?.0 as jint))
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_dev_pixelstudio_app_bridge_NativeBridge_nativeHeight<'l>(mut env: JNIEnv<'l>, _class: JClass<'l>, handle: jlong) -> jint {
    guarded(&mut env, 0, |_| Ok(ops::dimensions(handle as u64)?.1 as jint))
}

/// `nativeRenderPremultiplied(handle: Long, dst: ByteBuffer)`.
/// `dst` must be a *direct* ByteBuffer; its position/limit are ignored and its capacity is the
/// writable size. Kotlin owns the buffer and must not touch it until this call returns.
#[unsafe(no_mangle)]
pub extern "system" fn Java_dev_pixelstudio_app_bridge_NativeBridge_nativeRenderPremultiplied<'l>(
    mut env: JNIEnv<'l>,
    _class: JClass<'l>,
    handle: jlong,
    dst: JByteBuffer<'l>,
) {
    guarded(&mut env, (), |env| {
        let ptr = env.get_direct_buffer_address(&dst).map_err(jni_err)?;
        let cap = env.get_direct_buffer_capacity(&dst).map_err(jni_err)?;
        if ptr.is_null() {
            return Err(BridgeError::Jni("destination is not a direct ByteBuffer".into()));
        }
        // SAFETY: `ptr`/`cap` describe the memory of a live direct ByteBuffer that Kotlin keeps
        // referenced for the duration of this call and does not access concurrently (documented
        // contract). The slice does not outlive this closure and is the only reference to the memory.
        let slice = unsafe { std::slice::from_raw_parts_mut(ptr, cap) };
        ops::render_premultiplied(handle as u64, slice)?;
        Ok(())
    })
}

/// `nativeExportPng(handle: Long): ByteArray`. Returns a new Java byte[] owned by the JVM.
#[unsafe(no_mangle)]
pub extern "system" fn Java_dev_pixelstudio_app_bridge_NativeBridge_nativeExportPng<'l>(mut env: JNIEnv<'l>, _class: JClass<'l>, handle: jlong) -> jbyteArray {
    guarded(&mut env, std::ptr::null_mut(), |env| {
        let png = ops::export_png(handle as u64)?;
        let arr = env.byte_array_from_slice(&png).map_err(jni_err)?;
        Ok(arr.into_raw())
    })
}

/// `nativeExportJpeg(handle: Long, quality: Int): ByteArray` (quality 1..=100).
#[unsafe(no_mangle)]
pub extern "system" fn Java_dev_pixelstudio_app_bridge_NativeBridge_nativeExportJpeg<'l>(
    mut env: JNIEnv<'l>,
    _class: JClass<'l>,
    handle: jlong,
    quality: jint,
) -> jbyteArray {
    guarded(&mut env, std::ptr::null_mut(), |env| {
        let q = u8::try_from(quality).map_err(|_| BridgeError::InvalidArgument(format!("JPEG quality out of range: {quality}")))?;
        let jpg = ops::export_jpeg(handle as u64, q)?;
        let arr = env.byte_array_from_slice(&jpg).map_err(jni_err)?;
        Ok(arr.into_raw())
    })
}

/// `nativeLastExportWarnings(): String`: the exporter's warnings for the latest export, one per line
/// (empty string if none).
#[unsafe(no_mangle)]
pub extern "system" fn Java_dev_pixelstudio_app_bridge_NativeBridge_nativeLastExportWarnings<'l>(mut env: JNIEnv<'l>, _class: JClass<'l>) -> jstring {
    guarded(&mut env, std::ptr::null_mut(), |env| {
        let text = ops::last_export_warnings().join("\n");
        Ok(env.new_string(text).map_err(jni_err)?.into_raw())
    })
}

#[unsafe(no_mangle)]
pub extern "system" fn Java_dev_pixelstudio_app_bridge_NativeBridge_nativeClose<'l>(_env: JNIEnv<'l>, _class: JClass<'l>, handle: jlong) -> jboolean {
    jboolean::from(ops::close(handle as u64))
}
