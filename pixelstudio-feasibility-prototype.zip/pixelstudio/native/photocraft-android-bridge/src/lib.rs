//! Android bridge to the PhotoCraft import / composite / export code.
//!
//! * [`bridge_core`]: plain safe Rust, no JNI. Owns the document registry and the three engine calls
//!   (import, flatten, export). Unit-testable on the host with `cargo test`.
//! * `jni_glue`: the only module with `unsafe`; thin JNI entry points over [`bridge_core`].
//!
//! See docs/BRIDGE_INTERFACE.md for buffer ownership, pixel format, stride and error handling.

pub mod bridge_core;
mod jni_glue;

// The engine session: real implementation with `--features engine`, stubs that report
// `EngineUnavailable` otherwise, so the JNI surface is identical in both builds.
#[cfg(feature = "engine")]
#[path = "engine_session.rs"]
mod engine_session;
#[cfg(not(feature = "engine"))]
#[path = "engine_stub.rs"]
mod engine_session;
