//! JNI-free core. Every engine call below was checked against the upstream source:
//!   photocraft_io::import(name: &str, bytes: &[u8]) -> Result<ImportResult, IoError>
//!   photocraft_compose::flatten(&Document) -> Buffer   (straight-alpha f32 RGBA, `rect`, `px`)
//!   Buffer::to_rgba8() -> Rgba8Image { width, height, pixels }   (straight-alpha RGBA8, tight rows)
//!   photocraft_io::export(&Document, name_or_ext: &str, &ExportOptions) -> Result<ExportResult, IoError>
//!   Document::bounds() -> Rect;  Rect::width()/height() -> u32

use std::collections::HashMap;
use std::fmt;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex, OnceLock, PoisonError};

use photocraft_doc::Document;

/// Bumped whenever the Kotlin <-> Rust contract changes. Kotlin checks it after loading the library.
pub const ABI_VERSION: i32 = 2;

/// Prototype limit on width * height. `flatten` produces 16 bytes per pixel (f32 RGBA) before it is
/// quantised to 8 bits, so 12 MP needs roughly 190 MB transiently on top of the document itself.
pub const MAX_PIXELS: u64 = 12_000_000;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BridgeError {
    EmptyInput,
    Import(String),
    TooLarge { width: u64, height: u64 },
    InvalidHandle(u64),
    InvalidArgument(String),
    BufferTooSmall { needed: usize, got: usize },
    Render(String),
    Export(String),
    Jni(String),
}

impl fmt::Display for BridgeError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::EmptyInput => write!(f, "no image data was provided"),
            Self::Import(e) => write!(f, "could not import the image: {e}"),
            Self::TooLarge { width, height } => {
                write!(f, "image is {width}x{height}, over the {MAX_PIXELS}-pixel prototype limit")
            }
            Self::InvalidHandle(h) => write!(f, "invalid or already closed document handle {h}"),
            Self::InvalidArgument(e) => write!(f, "invalid argument: {e}"),
            Self::BufferTooSmall { needed, got } => {
                write!(f, "pixel buffer too small: need {needed} bytes, got {got}")
            }
            Self::Render(e) => write!(f, "render failed: {e}"),
            Self::Export(e) => write!(f, "export failed: {e}"),
            Self::Jni(e) => write!(f, "JNI error: {e}"),
        }
    }
}

impl std::error::Error for BridgeError {}

// Handles are opaque, never-reused u64 ids, not pointers: a stale or forged id yields
// `InvalidHandle` instead of undefined behaviour. 0 is never issued.
static NEXT_HANDLE: AtomicU64 = AtomicU64::new(1);

type Registry = Mutex<HashMap<u64, Arc<Document>>>;

fn registry() -> &'static Registry {
    static REGISTRY: OnceLock<Registry> = OnceLock::new();
    REGISTRY.get_or_init(|| Mutex::new(HashMap::new()))
}

fn lock() -> std::sync::MutexGuard<'static, HashMap<u64, Arc<Document>>> {
    registry().lock().unwrap_or_else(PoisonError::into_inner)
}

fn get(handle: u64) -> Result<Arc<Document>, BridgeError> {
    lock().get(&handle).cloned().ok_or(BridgeError::InvalidHandle(handle))
}

/// Decodes `bytes` with the PhotoCraft importer and registers the document. `name` (the file's
/// display name) is passed through to the importer, which may use its extension.
pub fn open_image(bytes: &[u8], name: &str) -> Result<u64, BridgeError> {
    if bytes.is_empty() {
        return Err(BridgeError::EmptyInput);
    }
    let imported = photocraft_io::import(name, bytes).map_err(|e| BridgeError::Import(e.to_string()))?;
    let doc = imported.document;
    let bounds = doc.bounds();
    let (w, h) = (u64::from(bounds.width()), u64::from(bounds.height()));
    if w == 0 || h == 0 {
        return Err(BridgeError::Import("the image has no pixels".into()));
    }
    if w * h > MAX_PIXELS {
        return Err(BridgeError::TooLarge { width: w, height: h });
    }
    let handle = NEXT_HANDLE.fetch_add(1, Ordering::Relaxed);
    lock().insert(handle, Arc::new(doc));
    Ok(handle)
}

/// Canvas size in pixels.
pub fn dimensions(handle: u64) -> Result<(u32, u32), BridgeError> {
    let doc = get(handle)?;
    let b = doc.bounds();
    Ok((b.width(), b.height()))
}

/// Flattens the document and writes **premultiplied** RGBA8 into `dst` (row stride = width * 4,
/// no padding, top row first). Returns (width, height). `dst` may be larger than needed; only the
/// first width*height*4 bytes are written.
///
/// Premultiplied is what `android.graphics.Bitmap` (ARGB_8888, the default) stores in memory, so
/// Kotlin can `copyPixelsFromBuffer` without any per-pixel work.
pub fn render_premultiplied(handle: u64, dst: &mut [u8]) -> Result<(u32, u32), BridgeError> {
    let doc = get(handle)?;
    let b = doc.bounds();
    let (w, h) = (b.width(), b.height());
    let needed = (w as usize)
        .checked_mul(h as usize)
        .and_then(|n| n.checked_mul(4))
        .ok_or_else(|| BridgeError::Render("size overflow".into()))?;
    if dst.len() < needed {
        return Err(BridgeError::BufferTooSmall { needed, got: dst.len() });
    }

    let buffer = photocraft_compose::flatten(&doc);
    // `render` documents that rects past its pixel cap return an empty buffer instead of aborting.
    if buffer.px.is_empty() || buffer.rect.width() != w || buffer.rect.height() != h {
        return Err(BridgeError::Render("compositor returned an empty or mis-sized buffer".into()));
    }
    let rgba8 = buffer.to_rgba8();
    drop(buffer); // release the 16-byte-per-pixel float buffer before anything else is allocated
    if rgba8.width != w || rgba8.height != h || rgba8.pixels.len() != needed {
        return Err(BridgeError::Render("unexpected RGBA8 image size".into()));
    }

    for (out, src) in dst[..needed].chunks_exact_mut(4).zip(rgba8.pixels.chunks_exact(4)) {
        let a = u32::from(src[3]);
        out[0] = premul(src[0], a);
        out[1] = premul(src[1], a);
        out[2] = premul(src[2], a);
        out[3] = src[3];
    }
    Ok((w, h))
}

#[inline]
fn premul(c: u8, a: u32) -> u8 {
    ((u32::from(c) * a + 127) / 255) as u8
}

/// Warnings the exporter reported for the most recent export (for example "alpha will be
/// discarded" when a transparent image is saved as JPEG). One slot for the whole process: the app
/// runs one export at a time and reads this right after the export call returns.
static LAST_WARNINGS: Mutex<Vec<String>> = Mutex::new(Vec::new());

fn set_warnings(w: Vec<String>) {
    *LAST_WARNINGS.lock().unwrap_or_else(PoisonError::into_inner) = w;
}

/// Warnings of the most recent export (empty if none, or if it failed).
pub fn last_export_warnings() -> Vec<String> {
    LAST_WARNINGS.lock().unwrap_or_else(PoisonError::into_inner).clone()
}

fn export_as(handle: u64, file_name: &str, jpeg_quality: Option<u8>) -> Result<Vec<u8>, BridgeError> {
    let doc = get(handle)?;
    set_warnings(Vec::new());
    let mut opts = photocraft_io::ExportOptions::default();
    if let Some(q) = jpeg_quality {
        opts.encode.jpeg_quality = q;
    }
    let out = photocraft_io::export(&doc, file_name, &opts).map_err(|e| BridgeError::Export(e.to_string()))?;
    set_warnings(out.warnings);
    Ok(out.bytes)
}

/// Encodes the document as PNG through the PhotoCraft exporter (straight alpha, as the format
/// requires). This exports the document itself, not the preview pixels.
pub fn export_png(handle: u64) -> Result<Vec<u8>, BridgeError> {
    export_as(handle, "export.png", None)
}

/// Encodes the document as JPEG (`quality` 1..=100) through the PhotoCraft exporter. JPEG has no
/// alpha: the exporter reports a warning when transparent pixels are discarded (see
/// [`last_export_warnings`]); how it fills them has not been verified on a device.
pub fn export_jpeg(handle: u64, quality: u8) -> Result<Vec<u8>, BridgeError> {
    if !(1..=100).contains(&quality) {
        return Err(BridgeError::InvalidArgument(format!("JPEG quality must be 1..=100, got {quality}")));
    }
    export_as(handle, "export.jpg", Some(quality))
}

/// Drops the document. Returns false if the handle was unknown (already closed).
pub fn close(handle: u64) -> bool {
    lock().remove(&handle).is_some()
}

#[cfg(test)]
mod tests {
    use super::*;

    const PNG_2X2: &[u8] = include_bytes!("../tests/fixtures/rgba_2x2.png");

    #[test]
    fn imports_and_reports_dimensions() {
        let h = open_image(PNG_2X2, "rgba_2x2.png").expect("import");
        assert_eq!(dimensions(h), Ok((2, 2)));
        assert!(close(h));
    }

    #[test]
    fn render_is_premultiplied_rgba_with_tight_stride() {
        let h = open_image(PNG_2X2, "rgba_2x2.png").unwrap();
        let mut buf = vec![0xEE_u8; 2 * 2 * 4 + 8]; // deliberately oversized
        assert_eq!(render_premultiplied(h, &mut buf), Ok((2, 2)));
        assert_eq!(&buf[0..4], &[255, 0, 0, 255], "pixel (0,0) opaque red");
        assert_eq!(&buf[4..8], &[0, 255, 0, 255], "pixel (1,0) opaque green");
        assert_eq!(&buf[8..12], &[0, 0, 255, 255], "pixel (0,1) opaque blue");
        // pixel (1,1): white at alpha 128 -> premultiplied ~128 on every channel (tolerance 2)
        for c in 0..4 {
            assert!((i32::from(buf[12 + c]) - 128).abs() <= 2, "channel {c} = {}", buf[12 + c]);
        }
        assert!(buf[16..].iter().all(|&b| b == 0xEE), "bytes past the image must be untouched");
        close(h);
    }

    #[test]
    fn export_png_round_trips() {
        let h = open_image(PNG_2X2, "rgba_2x2.png").unwrap();
        let png = export_png(h).expect("export");
        assert_eq!(&png[..8], b"\x89PNG\r\n\x1a\n");
        let h2 = open_image(&png, "again.png").expect("re-import");
        assert_eq!(dimensions(h2), Ok((2, 2)));
        close(h);
        close(h2);
    }

    #[test]
    fn export_jpeg_produces_a_jpeg_that_reimports() {
        let h = open_image(PNG_2X2, "rgba_2x2.png").unwrap();
        let jpg = export_jpeg(h, 90).expect("export");
        assert_eq!(&jpg[..3], &[0xFF, 0xD8, 0xFF], "JPEG SOI marker");
        let h2 = open_image(&jpg, "again.jpg").expect("re-import");
        assert_eq!(dimensions(h2), Ok((2, 2)));
        close(h);
        close(h2);
    }

    #[test]
    fn jpeg_quality_is_validated() {
        let h = open_image(PNG_2X2, "a.png").unwrap();
        assert!(matches!(export_jpeg(h, 0), Err(BridgeError::InvalidArgument(_))));
        assert!(matches!(export_jpeg(h, 101), Err(BridgeError::InvalidArgument(_))));
        close(h);
    }

    #[test]
    fn errors_are_explicit() {
        assert_eq!(open_image(&[], "x.png"), Err(BridgeError::EmptyInput));
        assert!(matches!(open_image(b"definitely not an image", "x.png"), Err(BridgeError::Import(_))));
        assert_eq!(dimensions(999_999), Err(BridgeError::InvalidHandle(999_999)));
        let h = open_image(PNG_2X2, "a.png").unwrap();
        let mut tiny = [0u8; 4];
        assert!(matches!(render_premultiplied(h, &mut tiny), Err(BridgeError::BufferTooSmall { needed: 16, got: 4 })));
        assert!(close(h));
        assert!(!close(h), "second close reports the handle as unknown");
        assert_eq!(export_png(h), Err(BridgeError::InvalidHandle(h)));
    }
}
