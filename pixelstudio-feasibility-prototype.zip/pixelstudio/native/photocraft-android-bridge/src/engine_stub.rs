//! Used when the crate is built WITHOUT `--features engine`: every call reports that the engine is
//! not part of this build. Signatures mirror engine_session.rs exactly.

use crate::bridge_core::BridgeError;

pub const AVAILABLE: bool = false;

pub fn open_image(_bytes: Vec<u8>, _name: String) -> Result<(), BridgeError> {
    Err(BridgeError::EngineUnavailable)
}
pub fn execute(_id: String, _params_json: String) -> Result<String, BridgeError> {
    Err(BridgeError::EngineUnavailable)
}
pub fn commands_json() -> Result<String, BridgeError> {
    Err(BridgeError::EngineUnavailable)
}
pub fn dimensions() -> Result<(u32, u32), BridgeError> {
    Err(BridgeError::EngineUnavailable)
}
pub fn render_premultiplied(_dst: &mut [u8]) -> Result<(u32, u32), BridgeError> {
    Err(BridgeError::EngineUnavailable)
}
pub fn export_png() -> Result<Vec<u8>, BridgeError> {
    Err(BridgeError::EngineUnavailable)
}
pub fn export_jpeg(_quality: u8) -> Result<Vec<u8>, BridgeError> {
    Err(BridgeError::EngineUnavailable)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn every_call_reports_engine_unavailable() {
        assert!(!AVAILABLE);
        assert_eq!(commands_json(), Err(BridgeError::EngineUnavailable));
        assert_eq!(execute("edit.undo".into(), "{}".into()), Err(BridgeError::EngineUnavailable));
        assert_eq!(dimensions(), Err(BridgeError::EngineUnavailable));
    }
}
