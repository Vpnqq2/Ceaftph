#!/usr/bin/env python3
"""Lists what the bridge's upstream dependencies pull in, according to upstream's Cargo.lock.

Usage: python3 scripts/lock_closure.py [path/to/photocraft-main/Cargo.lock] [root-package ...]
Default roots: photocraft-io photocraft-compose photocraft-doc (add photocraft-engine to check the engine).

Caveats (this is a static read of the lockfile, not `cargo tree`):
  * Cargo.lock lists dependencies for every platform and includes dev-dependencies of workspace
    members, so the closure over-counts what an Android release build compiles.
  * It cannot see cfg(target_os) gating. Run `cargo tree --target aarch64-linux-android -p
    photocraft-android-bridge` (after the first build) for the authoritative list.
"""
import re
import sys

path = sys.argv[1] if len(sys.argv) > 1 else "../photocraft-main/Cargo.lock"
ROOTS = sys.argv[2:] or ["photocraft-io", "photocraft-compose", "photocraft-doc"]
text = open(path, encoding="utf-8").read()

packages = {}
for block in text.split("[[package]]")[1:]:
    name = re.search(r'name = "([^"]+)"', block).group(1)
    version = re.search(r'version = "([^"]+)"', block).group(1)
    source = re.search(r'source = "([^"]+)"', block)
    deps = re.search(r"dependencies = \[(.*?)\n\]", block, re.S)
    packages.setdefault(name, []).append(
        (version, source.group(1) if source else None, re.findall(r'"([^"]+)"', deps.group(1)) if deps else [])
    )

def resolve(dep):
    parts = dep.split(" ")
    candidates = packages.get(parts[0], [])
    if len(parts) > 1:
        candidates = [c for c in candidates if c[0] == parts[1]] or candidates
    return (parts[0], candidates[0]) if candidates else (parts[0], None)

seen, stack = {}, list(ROOTS)
while stack:
    name, entry = resolve(stack.pop())
    if entry is None or (name, entry[0]) in seen:
        continue
    seen[(name, entry[0])] = entry
    stack.extend(entry[2])

names = sorted({n for n, _ in seen})
git = sorted((n, v, s.split("#")[0]) for (n, v), (_, s, _) in seen.items() if s and s.startswith("git+"))
print(f"packages in closure (all platforms, incl. dev-deps): {len(seen)}")
print("git-sourced packages:")
for n, v, s in git:
    print(f"  {n} {v}  {s}")
watch = ["wasmi", "ipp", "craft-print", "winprint", "printpdf", "cups", "libc", "rustix", "mio", "tokio", "reqwest", "ureq", "hyper", "openssl", "openssl-sys", "ring", "rustls", "native-tls", "arboard", "rfd", "cpal", "alsa-sys", "ort", "tract-onnx", "onnxruntime"]
print("platform-sensitive crates present:", [n for n in watch if n in names])
for label, group in (
    ("UI/GPU crates that must NOT be here", ["egui", "eframe", "winit", "wgpu", "winprint", "craft-print", "craft-ui", "craft-update"]),
    ("native-build / sys crates to watch when cross-compiling", [n for n in names if n.endswith("-sys") or n in ("cc", "cmake", "bindgen", "pkg-config")]),
):
    print(f"{label}: {[n for n in group if n in names] if label.startswith('UI') else group}")
